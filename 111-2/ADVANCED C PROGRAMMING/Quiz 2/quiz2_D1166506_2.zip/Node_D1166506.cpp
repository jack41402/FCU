// Implement the class nodes of single-linked linear list, Node.

#include <cstdlib>
#include "Node_D1166506.h"

Node::Node ()
{
	next = NULL ;
	data = ' ' ;
}

char Node::getNode ()
{
	return data ;
}
