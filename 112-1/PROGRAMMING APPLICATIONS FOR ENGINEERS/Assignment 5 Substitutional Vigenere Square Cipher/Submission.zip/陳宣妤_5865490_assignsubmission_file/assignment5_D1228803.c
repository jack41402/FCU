#include<stdio.h> //Includes the Standard Input Output header file in the program, which contains functions for input and output operations
#include<string.h> //Includes the String header file, which contains functions for dealing with strings
#include<ctype.h> //Includes the Character Type header file, which provides functions for testing and mapping characters

char* removeNonAlphabetic(char* p)  //Starts the definition of a function named 
{
    int l = strlen(p); //Initializes an integer l to the length of the string
    for (int i = 0; i < l; i++) //Iterates over each character in the string p
	{
        if (!isalpha(p[i])) //Checks if the current character is not an alphabetic character using isalpha
		{
            for (int j = i; j < l; j++) //Shifts all characters to the left starting from the non-alphabetic character found
			{
                p[j] = p[j + 1]; //Assigns the value of the next character to the current character, effectively removing the non-alphabetic character
            }
            l = l - 1; //Decreases the length of the string by one
            i -= 1; //Decrements the loop counter to check the new character at the current index
        }
    }
    return p; //Returns the modified string
}

char* convertToUppercase(char* p) //Begins the definition of a function that converts a string to uppercase
{
    int l = strlen(p); //Initializes an integer l to the length of the string p
    for (int i = 0; i < l; i++) //Iterate over each character of the string
	{
        if (islower(p[i])) //Checks if the current character is a lowercase letter
		{
            p[i] = toupper(p[i]); //Converts the lowercase letter to uppercase
        }
    }
    return p; //Returns the uppercase string
}

void printVigenereSquareSection(char* code_book, char* decode_book) //Begins the definition of a function that prints a section of the Vigenere square using the given code book and decodes book arrays
{
    printf(">>>>The first code book:\n"); //Print out the first code book
    for (int i = 0; i < 26; ++i) //The corresponding characters for the code and decode books
	{
        printf("%c", i + 'A'); //Print out the corresponding characters 
    }
    printf("\n    ");  
    for (int i = 0; i < 26; ++i) //The corresponding characters for the code and decode books
	{
        printf("%c", code_book[i]); //Print out the corresponding characters 
    }
    printf("\n>>>>The first decode book:\n"); //The corresponding characters for the code and decode books
    for (int i = 0; i < 26; ++i) 
	{
        printf("%c", i + 'A'); //Print out the corresponding characters 
        decode_book[code_book[i] - 'A'] = i + 'A';//Print out the corresponding characters 
    }
    printf("\n    ");
    for (int i = 0; i < 26; ++i) //The corresponding characters for the code and decode books
	{
        printf("%c", decode_book[i]); //Print out the corresponding characters 
    }
    printf("\n");
}

void vigenereEncode(char* plainText, char* keyword, char* code_book) //Starts the definition of a function to encode text using the Vigenere cipher
{
    printf("Encoded Text: "); //Print out the encode text
    int j = 0; //Initializes and uses variables for encoding the text
    int len = strlen(keyword); //Initializes and uses variables for encoding the text
    int textLen = strlen(plainText); //Initializes and uses variables for encoding the text

    for (int i = 0; i < textLen; i++) //Encoding each character, and prints the encoded text
	{
        if (plainText[i] >= 'A' && plainText[i] <= 'Z') 
		{
            plainText[i] = code_book[plainText[i] - 'A'];
        }
        printf("%c", plainText[i]);
        j = (j + 1) % len;
    }
    printf("\n");
}

void vigenereDecode(char* encodedText, char* keyword, char* decode_book) //Starts the definition of a function to decode text using the Vigenere cipher
{
    printf("Decoded Text: "); //Print out the decoded text
    int j = 0; //Initializes and uses variables for decoding the text
    int len = strlen(keyword); //Initializes and uses variables for decoding the text
    int textLen = strlen(encodedText); //Initializes and uses variables for decoding the text

    for (int i = 0; i < textLen; i++) //Decoding each character, and prints the decoded text
	{
        if (isalpha(encodedText[i])) 
		{
            char decodedChar = decode_book[encodedText[i] - 'A'];
            printf("%c", decodedChar);
        } else 
		{
            printf("%c", encodedText[i]);
        }
        j = (j + 1) % len;
    }
    printf("\n");
}

int main() //Begins the main function of the program
{
	//Declares character arrays for the keyword, plaintext, code book, and decode book
    char keyword[41];  
    char plainText[101];   
    char code_book[26] = {'N', 'E', 'I', 'Q', 'O', 'Y', 'A', 'R', 'D', 'C', 'S', 'H', 'X',
                          'Z', 'B', 'P', 'J', 'T', 'K', 'U', 'F', 'L', 'V', 'G', 'W', 'M'};
    char decode_book[26];

    printf("Enter a keyword: "); //Prompts the user to enter a keyword and a line of text, and reads them
    fgets(keyword, sizeof(keyword), stdin);
    keyword[strcspn(keyword, "\n")] = '\0';

    printf("Enter a line of English text: "); //Prompts the user to enter a keyword and a line of text, and reads them
    fgets(plainText, sizeof(plainText), stdin);
    plainText[strcspn(plainText, "\n")] = '\0';

    printf("\n**** The keyword is: %s\n", keyword); //Print out the keyword
    printf(">>>>The original text: %s\n\n", plainText); //Print out the keyword

    printVigenereSquareSection(code_book, decode_book); //Calls the printVigenereSquareSection function

	 
    removeNonAlphabetic(plainText); //Processes the entered text to remove non-alphabetic characters
    convertToUppercase(plainText); //Processes the convert to uppercase

	char originalText[41]; //Declares an array originalText to store the modified plaintext
    strcpy(originalText, plainText); //Copies the modified plaintext to originalText

    vigenereEncode(plainText, keyword, code_book); //Calls the vigenereEncode functions

    vigenereDecode(plainText, keyword, decode_book); //Calls the vigenereDecode functions

    return 0; //To indicate the successful execution of a program
}

