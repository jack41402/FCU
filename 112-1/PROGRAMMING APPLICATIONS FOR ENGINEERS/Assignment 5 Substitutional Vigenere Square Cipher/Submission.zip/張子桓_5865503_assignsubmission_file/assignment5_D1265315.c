#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(void) { 
    //                     A    B    C    D    E    F    G    H    I    J    K    L    M    
	char code_book[26] = {'N', 'E', 'I', 'Q', 'O', 'Y', 'A', 'R', 'D', 'C', 'S', 'H', 'X',  
	//                     N    O    P    Q    R    S    T    U    V    W    X    Y    Z   
  	                      'Z', 'B', 'P', 'J', 'T', 'K', 'U', 'F', 'L', 'V', 'G', 'W', 'M'};
    char decode_book[26];
    char keyword[41];
    int selected_book;
    int key_leng;
    char original_text[101];
    char encoded_text[101];
    char decoded_text[101];
    int i, j;
    
    printf("Enter a keyword: ");
    scanf("%s", &keyword);
    getchar();
    printf("\n");
    key_leng = strlen(keyword);
    printf("Enter a line of English text: ");
    i = 0;
    do {
        original_text[i++] = getchar();
    } while (original_text[i-1] != '\n');
    original_text[i-1] = '\0';
    printf("\n**** The keyword is: %s\n", keyword);
    printf(">>>> The original text: %s\n\n", original_text);
    
    // Generate decode_book using code_book
    for(i=0;i<26;i++) decode_book[code_book[i]-'A'] = i + 'A';

    // Print code and decode books
    for(i=0;i<4;i++){
        if(i==0) printf(">>>> The first code book:\n");
        if(i==2) printf(">>>> The first decode book:\n");
        printf("    ");
        if(i==0||i==2) for(j=0;j<26;j++) printf("%c ",j+'A');
        if(i==1) for(j=0;j<26;j++) printf("%c ",code_book[j]);
        if(i==3) for(j=0;j<26;j++) printf("%c ",decode_book[j]);
        if(i==1||i==3) printf("\n");
        printf("\n");
    }

    // Encode the text
    j = 0;
    for(i=0;i<strlen(original_text);i++){
        if(isalpha(original_text[i])){
            encoded_text[j] = code_book[((toupper(original_text[i])-'A')+(decode_book[keyword[j%key_leng]-'A']-'A'))%26];
            j++;
        }
    }
    encoded_text[j] = '\0';
    printf(">>>> The encoded text: %s\n\n", encoded_text);

    // Decode the encoded text
    for(i=0;i<strlen(encoded_text);i++)
        decoded_text[i] = decode_book[code_book[((decode_book[encoded_text[i]-'A']-'A')-(decode_book[keyword[i % key_leng]-'A']-'A')+26)%26]-'A'];
    decoded_text[strlen(encoded_text)] = '\0';
    printf(">>>> The decoded text: %s",decoded_text);

    return 0;
}
