#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(void) {
    // The first code book.
    //                     A    B    C    D    E    F    G    H    I    J    K    L    M
    char code_book[26] = {'N', 'E', 'I', 'Q', 'O', 'Y', 'A', 'R', 'D', 'C', 'S', 'H', 'X',
    //                     N    O    P    Q    R    S    T    U    V    W    X    Y    Z
                            'Z', 'B', 'P', 'J', 'T', 'K', 'U', 'F', 'L', 'V', 'G', 'W', 'M'};
    char decode_book[26];
    char keyword[41];
    int selected_book=0;
    int key_leng;
    char original_text[101];
    char encoded_text[101];
    char decoded_text[101];
    int i, j;
    // Input a keyword and an English text.
    printf("Enter a keyword: ");
    scanf("%s", keyword);
    getchar();
    printf("\n");
    key_leng = strlen(keyword);
    printf("Enter a line of English text: "); // Input the testing text.
    i = 0;
    do {
        original_text[i++] = getchar(); // Input a character from the console.
    } while (original_text[i-1] != '\n'); // Stop until the newline.
    original_text[i-1] = '\0'; // Insert end-of-string.
    printf("\n**** The keyword is: %s\n", keyword);
    printf(">>>> The original text: %s\n\n", original_text);
    printf(">>>> The first code book:\n    ");
    for(i=0;i<26;i++){
        printf("%c ", 'A'+i);
    }
    printf("\n    ");
    for(i=0;i<26;i++){
        printf("%c ", code_book[i]);
    }
    j=0;
    for(i=0;i<strlen(original_text);i++){
        if(isalpha(original_text[i])) original_text[j++]=toupper(original_text[i]);
    }
    original_text[j]='\0';
    for(i=0;i<strlen(original_text);i++){//produce the encoded text
        for(j=0;j<26;j++){
            if(code_book[j]==keyword[i%key_leng]) selected_book=j;
        }
        encoded_text[i]=code_book[(original_text[i]-'A'+selected_book)%26];
    }
    for(i=0;i<26;i++){//produce the decode book
        decode_book[code_book[i]-'A']='A'+i;
    }
    for(i=0;i<strlen(encoded_text);i++){//produce the decoded text
        for(j=0;j<26;j++){
            if(code_book[j]==keyword[i%key_leng]) selected_book=j;
        }
        decoded_text[i]=decode_book[encoded_text[i]-'A']-selected_book;
        if(decoded_text[i]<'A') decoded_text[i]=decoded_text[i]+26;
    }
    decoded_text[i]='\0';
    printf("\n\n>>>> The first decode book:\n    ");
    for(i=0;i<26;i++){
        printf("%c ", 'A'+i);
    }
    printf("\n    ");
    for(i=0;i<26;i++){
        printf("%c ", decode_book[i]);
    }
    printf("\n\n>>>> The encoded text: %s\n", encoded_text);
    printf("\n>>>> The decoded text: %s\n\n", decoded_text);
    return 0;
}
