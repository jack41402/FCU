#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define ALPHABET_SIZE 26
#define MAX_KEYWORD_LENGTH 40
#define MAX_TEXT_LENGTH 100

void inputText(char* prompt, char* text, int maxLength);
void printArray(const char* title, const char* array, int size);
void createDecodeBook(const char* codeBook, char* decodeBook);
void removeWhiteSpaceAndConvertToUpper(char* text);

int main(void) {
    char code_book[ALPHABET_SIZE] = {'N', 'E', 'I', 'Q', 'O', 'Y', 'A', 'R', 'D', 'C', 'S', 'H', 'X', 'Z', 'B', 'P', 'J', 'T', 'K', 'U', 'F', 'L', 'V', 'G', 'W', 'M'};
    char decode_book[ALPHABET_SIZE];
    char keyword[MAX_KEYWORD_LENGTH + 1];
    char original_text[MAX_TEXT_LENGTH + 1];
    char encoded_text[MAX_TEXT_LENGTH + 1];
    char decoded_text[MAX_TEXT_LENGTH + 1];

    inputText("Enter a keyword: ", keyword, MAX_KEYWORD_LENGTH);
    printf("\n");
    inputText("Enter a line of English text: ", original_text, MAX_TEXT_LENGTH);

    printf("\n**** The keyword is: %s", keyword);
    printf("\n");
    printf(">>>> The original text: %s\n", original_text);

    createDecodeBook(code_book, decode_book);
    printf("\n");
    printArray(">>>> The first code book:", code_book, ALPHABET_SIZE);
    printArray(">>>> The first decode book:", decode_book, ALPHABET_SIZE);

    removeWhiteSpaceAndConvertToUpper(original_text);

    int i;
    for (i = 0; i < strlen(original_text); i++) {
        encoded_text[i] = code_book[(original_text[i] - 'A' + decode_book[keyword[i % strlen(keyword)] - 'A'] - 'A') % ALPHABET_SIZE];
    }
    encoded_text[strlen(original_text)] = '\0';

    printf("\n>>>> The encoded text: %s\n\n", encoded_text);

    for (i = 0; i < strlen(encoded_text); i++) {
        decoded_text[i] = (decode_book[encoded_text[i] - 'A'] - 'A' - (decode_book[keyword[i % strlen(keyword)] - 'A'] - 'A') + ALPHABET_SIZE) % ALPHABET_SIZE + 'A';
    }
    decoded_text[strlen(encoded_text)] = '\0';

    printf(">>>> The decoded text: %s\n", decoded_text);

    return 0;
}

void inputText(char* prompt, char* text, int maxLength) {
    printf("%s", prompt);
    fgets(text, maxLength + 1, stdin);
    text[strcspn(text, "\n")] = '\0';  // Remove the newline character if present
}

void printArray(const char* title, const char* array, int size) {
    printf("%s\n    ", title);
    int i;
    for (i = 0; i < size; i++) {
        printf("%c ", 'A' + i);
    }
    printf("\n    ");
    for (i = 0; i < size; i++) {
        printf("%c ", array[i]);
    }
    printf("\n\n");
}

void createDecodeBook(const char* codeBook, char* decodeBook) {
    int i;
    for (i = 0; i < ALPHABET_SIZE; i++) {
        decodeBook[codeBook[i] - 'A'] = i + 'A';
    }
}

void removeWhiteSpaceAndConvertToUpper(char* text) {
    int i, j = 0;
    for (i = 0; i < strlen(text); i++) {
        if (text[i] != ' ') {
            text[j++] = toupper(text[i]);
        }
    }
    text[j] = '\0';
}

