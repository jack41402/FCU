#include<stdio.h>
#include<ctype.h>
#include<string.h>

int main(void){
	int i, a, x, n1, n2, key, num;
	int counts = 0, k = 0, keyl;
	char orgtxt[10001] = {}, oldtxt[10001] = {};
	char encodetxt[10001] = {}, decodetxt[10001] = {}, keyword[10001];
	char dgt[10001] = {}, kdgt[10001] = {};
 	char codebook[26] = {'N', 'E', 'I', 'Q', 'O', 'Y', 'A', 'R', 'D', 'C', 'S', 'H', 'X',   
                 	   	 'Z', 'B', 'P', 'J', 'T', 'K', 'U', 'F', 'L', 'V', 'G', 'W', 'M'};
    char decodebook[26];
    
	//generate the deocdebook
	for(i=0; i<26; i++){
		decodebook[codebook[i] - 'A'] = 'A' +  i;
	}
	
	//input keyword and original text
	printf("Enter a keyword: ");
	gets(keyword);
	printf("\n");
	printf("Enter a line of English text: ");
	gets(orgtxt);
	printf("\n");
	keyl = strlen(keyword);
	k = strlen(orgtxt);
		
	//convert to upper letter
	for(i=0; i<k; i++){
		oldtxt[i] = orgtxt[i];
		if(isalpha(orgtxt[i])){
			orgtxt[counts] = toupper(orgtxt[i]);
			counts++;
		}
	}
	
	//first encode
	for(i = 0; i<counts; i++){
		encodetxt[i] = codebook[orgtxt[i] - 'A'];
	} 
	
	//second encode
	for(i=0; i<counts; i++){
		key = i % keyl;
		for(a=0; a<26; a++){
			if(encodetxt[i] == codebook[a]){
				n1 = a;
			}
			if (keyword[key] == codebook[a]){
				n2 = a;
			}
		}
		num = n1 + n2;
		dgt[i] = num;
		kdgt[i] = n2;
		if (num >= 26){
			num = num - 26;
		}
		encodetxt[i] = codebook[num];
	}
	
	//first decode
	for(i=0; i<counts; i++){
		decodetxt[i] = codebook[dgt[i] - kdgt[i]];
	}
	
	//second decode
	for(i=0; i<counts; i++){
		decodetxt[i] = decodebook[decodetxt[i] - 'A'];
	}
	
	//output
	printf("****The key word is: %s\n", keyword);
	printf(">>>>The original text: %s\n\n", oldtxt);
	printf(">>>>The first code book is:\n");
	for(i=0; i<26; i++){
		printf("%c ", 'A' + i);
	}
	printf("\n");
	for(i=0; i<26; i++){
		printf("%c ", codebook[i]);
	}
	printf("\n\n");
	printf(">>>>The first decode book:\n");
	for(i=0; i<26; i++){
		printf("%c ", 'A' + i);
	}
	printf("\n");
	for(i=0; i<26; i++){
		printf("%c ", decodebook[i]);
	}
	printf("\n\n");
	printf(">>>>The encoded text: %s\n\n", encodetxt);
	printf(">>>>The decodeed text: %s\n", decodetxt);	
}
