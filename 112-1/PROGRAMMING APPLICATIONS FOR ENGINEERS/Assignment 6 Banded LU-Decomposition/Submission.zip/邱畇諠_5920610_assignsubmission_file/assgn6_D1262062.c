#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int max(int x, int y) {
    return (x > y) ? x : y;
}// Return the maximum value of x and y.

int min(int x, int y) {
    return (x < y) ? x : y;
}// Return the minimum value of x and y.

void banded_LU_decompose(int n, int r, int s, float** A, float** L, float** U) {
    int i, j, k;
    for(k = 0; k < n; ++k){
		for(j = k; j <= min(n-1, k+s); ++j) U[k][j] = A[k][j];//Compute elements of the k-th row of matrix U
		for(i = k; i <= min(n-1, k+r); ++i) L[i][k] = A[i][k] / A[k][k];//Compute elements of the k-th column of matrix L
		for(i = k+1; i <= min(n-1, k+r); ++i)//Compute elements of submatrix A(k+1)
			for(j = max(k+1, i-r); j <= min(n-1, min(i+s, k+s)); ++j)
				A[i][j] = A[i][j] - L[i][k] * U[k][j];
	}
}

int main(void) {
    float **A, **A1, **L, **U;
    int n, r, s;
    int check;
    int i, j, k;

    srand(time(NULL));// Seed of the random number generator.

    printf("Enter matrix size n: ");
    scanf("%d", &n);
    printf("\nEnter the lower bandwidth r and the upper bandwidth s of matrix A: ");
    scanf("%d %d", &r, &s);
	// Allocate the first and second dimensions of matrix A, A1, L, U.
    A = (float **)malloc(n * sizeof(float *));
    A1 = (float **)malloc(n * sizeof(float *));
    L = (float **)malloc(n * sizeof(float *));
    U = (float **)malloc(n * sizeof(float *));
    for (i = 0; i < n; ++i) {
        A[i] = (float *)malloc(n * sizeof(float));
        A1[i] = (float *)malloc(n * sizeof(float));
        L[i] = (float *)malloc((r + 1) * sizeof(float));
        U[i] = (float *)malloc((s + 1) * sizeof(float));
    }
	// Get random values for the elements of matrix A.
    for (i = 0; i < n; ++i)
        for (j = 0; j < n; ++j) {
            if (j >= i - r && j <= i + s)
                A[i][j] = (rand() % 10000 + 1) / 10000.0;
            else
                A[i][j] = 0.0;
            A1[i][j] = A[i][j];//A1[i][j] is the copy of A[i][j] for program verification.
        }

    printf("\nMatrix A:\n");
    for (i = 0; i < n; ++i) {
        for (j = 0; j < n; ++j) {
            if (j >= i - r && j <= i + s) {
                printf("%8.4f ", A[i][j]);
            } 
			else 
				printf("         ");
        }
        printf("\n");
    }

    banded_LU_decompose(n, r, s, A, L, U);// Peform banded_LU_decompose.

    printf("\nMatrix L:\n");
   	for (i = 0; i < n; ++i) {
	    for (j = 0; j <= i; ++j) {
	        if (j >= i - r) {
	            printf("%8.4f ", L[i][j]);
	        } 
			else 
	            printf("         ");
	    }
    	printf("\n");
	}	
  
    printf("\nMatrix U:\n");
    for (i = 0; i < n; ++i) {
    	for(j=0; j<i; ++j) 
			printf("         ");
        for (j = i; j <= min(n-1, i+s); ++j)
            printf("%8.4f ", U[i][j]);
        printf("\n");
    }

    check = 0; // Initial flag set to false.
	for (i = 0; i < n && !check; i++) {
    	for (j = 0; j < n && !check; j++) {
        	A[i][j] = 0;
        	for (k = 0; k <= min(i, j); k++)
            	A[i][j] += L[i][k] * U[k][j];
        	check = (fabs(A[i][j] - A1[i][j]) < 0.0001);// Compare A[i][j] and A1[i][j], allow error 0.0001.
    	}
	}

    if (check)
        printf("\nThe LU-decomposition program is correct.\n");
    else
        printf("\nThe LU-decomposition program is incorrect.\n");
    
    for(i=0; i<n; ++i){free(A[i]); free(A1[i]); free(L[i]); free(U[i]);}
	free(A);
	free(A1);
	free(L);
	free(U);
	
    return 0;
}
