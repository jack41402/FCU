#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <float.h>
#include <math.h>

int main()
{
    srand(time(NULL));
    int n,r,s;
    printf("Enter matrix size n: ");
    scanf("%d",&n);
    printf("\nEnter the lower bandwidth and the of matrix A, (r, s): ");
    scanf("%d %d",&r,&s);
    float L[n][n],U[n][n],A[n][n],A1[n][n];
    int i,j,k;//Loop variable.
    
    //Randomly generate A matrix.
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            L[i][j]=0;U[i][j]=0;//Set initial value 0.
            if(i-j>r || j-i>s)A[i][j]=0;
            else{
                float d=0;
                while(d==0){//Avoid 0.
                    d=(float)rand()/RAND_MAX;//Randomly generate decimals from 0 to 1.
                    d=(int)(d*10000)/10000.0;//To the fourth decimal place.
                }
                A[i][j]=d;
            }
            A1[i][j]=A[i][j];//Keep a copy of the A1 matrix.
        }
    }
    
    //Output A matrix.
    printf("\nMatrix A:\n");
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if(A[i][j]==0)printf("         ");
            else printf("%8.4lf ",A[i][j]);
        }
        printf("\n");
    }
    
    //LU-Decomposition.
    for(k=0;k<n;k++){
        //Compute elements of the k-th column of matrix L.
        for(i=k;i<n;i++){
            if(i-k>r)break;
            L[i][k]=A[i][k]/A[k][k];
        }
        //Compute elements of the k-th row of matrix U.
        for(j=k;j<n;j++){
            if(j>s+k)break;
            U[k][j]=A[k][j];
        }
        //Compute elements of submatrix A(k+1).
        for(i=k+1;i<n;i++){
            for(j=k+1;j<n;j++){
                A[i][j]=A[i][j]-L[i][k]*U[k][j];
            }
        }
    }
    
    //Output L,U matrix.
    printf("\nMatrix L:\n");
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if(L[i][j]==0)printf("         ");
            else printf("%8.4lf ",L[i][j]);
        }
        printf("\n");
    }
    printf("\nMatrix U:\n");
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if(U[i][j]==0)printf("         ");
            else printf("%8.4lf ",U[i][j]);
        }
        printf("\n");
    }
    
    //Check whether A1=L��U.
    bool error=0;
    float tolerance = 1e-5;//Tolerance value.
    for(i=0;i<n;i++){
        if(error)break;
        for(j=0;j<n;j++){
            float sum=0;
            for(k=0;k<n;k++)sum+=L[i][k]*U[k][j];
            if(fabs(sum - A1[i][j]) >= tolerance){
                error=1;
                break;
            }
        }
    }
    if(error)printf("\nThe LU-decomposition program is error.\n");
    else printf("\nThe LU-decomposition program is correct.\n");

    return 0;
}

