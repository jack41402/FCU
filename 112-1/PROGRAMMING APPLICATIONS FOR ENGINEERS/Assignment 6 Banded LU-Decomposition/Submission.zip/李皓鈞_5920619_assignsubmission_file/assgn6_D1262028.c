#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

// Return minimum value of x and y.
int min(int x, int y) {
  return x < y ? x : y;
}

// Macro to find the maximum of two values.
#define max(x, y) ((x) > (y) ? (x) : (y))

/* A: nxn banded matrix,
   L: nxn lower banded triangular matrix,
   U: nxn upper banded triangular matrix.
   Compute A=LU.
*/
void BandedLU_decompose(int n, int r, int s, float A[100][100], float L[100][100], float U[100][100]) {
  int i, j, k;

  for (k = 0; k < n; k++) { // To compute submatrix A(k+1).
    for (j = k; j < min(n, k + s + 1); j++) U[k][j] = A[k][j]; // Compute elements of the k-th row of matrix U
    for (i = k; i < min(n, k + r + 1); i++) L[i][k] = A[i][k] / A[k][k]; // Compute elements of the k-th column of matrix L
    for (i = k + 1; i < min(n, k + r + 1); i++) {
      for (j = max(k + 1, i - r); j < min(n, min(i + s, k + s + 1)); j++) {
        A[i][j] = A[i][j] - L[i][k] * U[k][j]; // Compute elements of submatrix A(k+1)
      }
    }
  }
}

int main(void) {
  float A[100][100], A1[100][100], L[100][100], U[100][100]; // Assume maximum 100 by 100 elements.
  int n, r, s; // Size and bandwidth of the square matrices.
  int check; // Flag to check the correctness of the program.
  int i, j, k; // Loop variables.

  srand(time(NULL)); // Seed of the random number generator.

  printf("Enter square matrix size n: "); // Input the matrix size.
  scanf("%d", &n);

  printf("Enter the lower bandwidth and the upper bandwidth of A, (r, s): "); // Input lower bandwidth and upper bandwidth.
  scanf("%d %d", &r, &s);

  // Get values for the elements of matrix A.
  // Matrix element A[i][j] is randomly generated non-banded elements.
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++) {
      if (j >= i - r && j <= i + s) {
        A[i][j] = (rand() % 10000 + 1) / 10000.0;
      } else {
        A[i][j] = 0.0;
      }
      A1[i][j] = A[i][j];
    }

  printf("\nMatrix A:\n"); // Output matrix A.
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (fabs(A[i][j]) < 0.0001) {
        printf("         ");  // Print blanks for small values
      } else {
        printf("%8.4f ", A[i][j]);
      }
    }
    printf("\n");
  }

  BandedLU_decompose(n, r, s, A, L, U); // Perform Banded LU-decomposition.

  printf("\nMatrix L:\n"); // Output matrix L.
  for (i = 0; i < n; i++) {
    for (j = 0; j < min(n, i + r + 1); j++) {
      if (fabs(L[i][j]) < 0.0001) {
        printf("         ");  // Print blanks for small values
      } else {
        printf("%8.4f ", L[i][j]);
      }
    }
    printf("\n");
  }

  printf("\nMatrix U:\n"); // Output matrix U.
  for (i = 0; i < n; i++) {
    for (j = 0; j < min(n, i + s + 1); j++) {
      if (fabs(U[i][j]) < 0.0001) {
        printf("         ");  // Print blanks for small values
      } else {
        printf("%8.4f ", U[i][j]);
      }
    }
    printf("\n");
  }

  check = 1; // Initial flag to true.
  for (i = 0; i < n && check; i++)
    for (j = 0; j < n && check; j++) {
      A[i][j] = 0;
      for (k = 0; k <= min(i, j); k++) A[i][j] += L[i][k] * U[k][j]; // Compute A[i][j] for A<=LU
      check = check && (fabs(A[i][j] - A1[i][j]) < 0.0001); // Compare A[i][j] and A1[i][j], allow error 0.0001.
    }

  if (check) printf("\nThe Banded LU-decomposition program is correct.\n"); // The program is correct.
  else printf("\nThe Banded LU-decomposition program is incorrect.\n"); // The program is incorrect.

  return 0;
}

