#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

float **newMatrix(int n){//create a matrix filled with zero
	int i = 0;
	int j = 0;
	float **M = malloc(sizeof(float *) * n);
	for(i = 0; i < n; i++){
		M[i] = malloc(sizeof(float) * n);
		for(j = 0; j < n; j++){
			M[i][j] = 0;
		}
	} 
	return M;
}

float **newBandedMatrix(int n, int r, int s){//create a matrix filled with random number
	int i = 0;
	int j = 0;
	float **M = newMatrix(n);
	for(i = 0; i < n; i++){
		for(j = 0; j < n; j++){
			if(i <= r + j && j <= s + i) M[i][j] = (float)rand() / RAND_MAX;
		}
	}
	return M;
}

void delMatrix(float **A, int n){// free the space 
	int i = 0;
	for(i = 0; i < n; i++){
		free(A[i]);
	}
	free(A);
}

float **copyMatrix(float **A, int n){// copy a matrix 
	int i = 0;
	int j = 0;
	float **M = newMatrix(n);
	for(i = 0; i < n; i++){
		for(j = 0; j < n; j++){
			M[i][j] = A[i][j];
		}
	}
	return M;
}

float **multMatrix(float **L, float **R, int n){// L matrix * R matrix
	int i = 0;
	int j = 0;
	int k = 0;
	float **M = newMatrix(n);
	for(i = 0; i < n; i++){
		for(j = 0; j < n; j++){
			for(k = 0; k < n; k ++){
				M[i][j] = M[i][j] + L[i][k] * R[k][j];
			}
		}
	}
	return M;
} 
void printBandedMatrix(float **A, int n, int r, int s){// print out the matrix
	int i = 0;
	int j = 0;
	for(i = 0; i < n; i++){
		for(j = 0; j < n; j++){
			if(i <= r + j && j <= s + i) printf("% 8.4f ", A[i][j]);
			else printf("         "); //don't print out more than r s.
		}
		printf("\n"); 
	}
}

int cmpMatrix(float **A, float **B, int n){// compute that if these are the same matrix
	int i = 0;
	int j = 0;
	for(i = 0; i < n; i++){
		for(j = 0; j < n; j++){
			if(fabsf(A[i][j] - B[i][j])> 0.0001) return 1;//don't use zero
		}
	}
	return 0;
}

int min(int a, int b){//compuute which one is smaller
	if(a > b) return b;
	else return a;
}
int max(int a, int b){//compute which one is bigger
	if(a > b) return a;
	else return b;
}
int main(){
	srand(time(NULL));
	int n = 0;
	int s = 0;
	int r = 0;
	int k = 0;
	int i = 0;
	int j = 0;
	float **A = NULL;
	float **L = NULL;
	float **U = NULL;
	float **M = NULL;
	float **A1 = NULL;
	
	printf("Enter matrix size n: ");
	scanf("%d", &n);
	printf("\nEnter the lower bandwidth and the upper bandwidth of matrix (r, s): ");
	scanf("%d %d", &r, &s);
	
	A = newBandedMatrix(n, r, s);//create matrix "A" 
	A1 = copyMatrix(A, n);// copy the matrix"A" for later calculation
	printf("\nMatrix A: \n");
	printBandedMatrix(A, n, r, s);// print out matrix "A"
	
	L = newBandedMatrix(n, r, 0);
	U = newBandedMatrix(n, 0, s);
	for(k = 0; k < n; k++){// follow the instruction given in text and make matrix L U and
		for(j = k; j <= min(n - 1, k + s); j++){
			U[k][j] = A[k][j];
		}
		for(i = k; i <= min(n - 1, k + r); i++){
			L[i][k] = A[i][k] / A[k][k];
		}
		for(i = k + 1; i <= min(n - 1, k + r); i++){
			for (j = max(k + 1, i - r); j <= min(n - 1, min(i + s, k + s)); j++) {
            A[i][j] = A[i][j] - L[i][k] * U[k][j];
            }
		}
	}
	printf("\nMatrix L:\n");
    printBandedMatrix(L, n, r, 0);

    printf("\nMatrix U:\n");
    printBandedMatrix(U, n, 0, s);

    M = multMatrix(L, U, n);
    if (!cmpMatrix(A1, M, n)) {//make sure L  * U will be A
        printf("\nThe LU-decomposition program is correct");
    }
    else {
        printf("\nThe LU-decomposition program is incorrect.");
    }

    delMatrix(M, n);//free the space of the matrix that we don't need anymore
    delMatrix(L, n);
    delMatrix(U, n);
    delMatrix(A1, n);
    delMatrix(A, n);
}
