#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h> 
// Return the maximum value of x and y.
int max(float x,float y){
	if(x>y) return x;
	else return y;
}
// Return the minimum value of x and y.
int min(float x,float y){
	if(x<y) return x;
	else return y;
}
void decomposition(int n, int s, int r, float A[100][100], float L[100][100], float U[100][100]){
	int i,j,k;
	for(i=0;i<n;i++){
		for(j=i;j<=min(s+i,n-1);j++) U[i][j] = A[i][j];
		for(j=i;j<=min(r+i,n-1);j++) L[j][i] = A[j][i] / A[i][i];
		for (j=i+1; j<n; j++){
      		for (k=i+1; k<=min(s+j,n-1); k++) A[j][k] = A[j][k] - L[j][i] * U[i][k];
  		}
	}
}//make a decomposition
int main(void){
	int n,r,s,i,j,k,check=1;
	float A[100][100], L[100][100], U[100][100], a[100][100];//setting the matrix
	float x=0.0;
	srand(time(NULL));	 // Seed of the random number generator.
	printf("Enter matrix size n: ");
	scanf("%d",&n);
	printf("\nEnter the lower bandwidth and the upper bandwidth of matrix A, (r,s): ");
	scanf("%d %d",&r,&s);
	for(i=0;i<n;i++){
		for(j=0;j<n;j++) A[i][j]=(rand() % 10000 + 1) / 10000.0;
	}//setting the matrix in random
	for(i=0;i<n;i++){
		for(j=max(0,i-r);j<=min(n-1,i+s);j++) a[i][j]=A[i][j];
	}
	printf("\nMatrix A:\n");
	for(i=0;i<n;i++){
		for(j=0;j<=max(0,i-r)-1;j++) printf("         ");
		for(j=max(0,i-r);j<=min(n-1,i+s);j++) printf("%8.4f ",A[i][j]);
		printf("\n");
	}//print the matrix
	decomposition(n, s, r, A, L, U);
	printf("\nMatrix L:\n");
	for(i=0;i<n;i++){
		for(j=0;j<=max(0,i-r)-1;j++) printf("         ");
		for(j=max(0,i-r);j<=i;j++) printf("%8.4f ",L[i][j]);
		printf("\n");
	}//print the matrix
	printf("\nMatrix U:\n");
	for(i=0;i<n;i++){
		for(j=0;j<i;j++) printf("         ");
		for(j=i;j<=min(s+i,n-1);j++) printf("%8.4f ",U[i][j]);
		printf("\n");
	}//print the matrix
	for(i=0;i<n;i++){
		for(j=max(0,i-r);j<=min(n-1,i+s);j++){
			for(k=0;k<n;k++){
				x=x+L[i][k]*U[k][j];
			}
			if((x-a[i][j])>=0.0001||(x-a[i][j])<=-0.0001) check=0;
			x=0.0;
		}
	}//Verify
	if (check) printf("\nThe LU-decomposition program is correct.\n"); // The program is correct.
  	else printf("\nThe LU-decomposition program is incorrect.\n"); // The program is incorrect.
	return 0;
}
