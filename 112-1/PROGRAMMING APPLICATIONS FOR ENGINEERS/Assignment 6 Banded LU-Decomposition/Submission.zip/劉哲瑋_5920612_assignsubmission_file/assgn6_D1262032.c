#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

int max(int x, int y){// Return the maximum value of x and y.
    if(x>y) return x;
    else return y;
}

int min(int x, int y){// Return the minimum value of x and y.
    if(x>y) return y;
    else return x;
}

int main(void) {
    int n, r, s, i, j, k, check=1;
    double A[100][100], L[100][100], U[100][100], A1[100][100];// Assume maximum 100 by 100 elements.
    printf("Enter matrix size n: ");
    scanf("%d", &n);
    printf("\nEnter the lower bandwidth and the of matrix A, (r, s): ");
    scanf("%d%d", &r, &s);
    srand((NULL));
    for(i=0;i<n;i++){
        for(j=max(0,i-r);j<=min(i+s,n-1);j++){// Matrix element A[i][j], 0<A[i][j]<=1
            A[i][j]=(rand()%10000+1)/10000.0;
        }
    }
    printf("\nMatrix A:\n");// Output non-zero elements of matrix A.
    for(i=0;i<n;i++){
        printf("  ");
        for(k=0;k<9*max(0,i-r);k++) printf(" ");
        for(j=max(0,i-r);j<=min(i+s,n-1);j++){
            printf("%.4lf   ", A[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<n;i++){//A1[i][j] is the copy of A[i][j] for program verification.
        for(j=0;j<n;j++){
            A1[i][j]=A[i][j];
        }
    }
    for(k=0;k<n;k++){// To compute submatrix A(k+1).
        for(i=k;i<=min(n-1,k+r);i++){
            L[i][k]=A[i][k]/A[k][k];
            if( i==k ) L[k][k]=1.0000;
        }
        for(j=k;j<=min(n-1, k+s);j++) U[k][j]=A[k][j];
        for(i=k+1;i<=min(n-1,k+r);i++){
            for(j=max(k+1, i-r);j<=min(n-1, min(i+s, k+s));j++){
                        A[i][j]=A[i][j]-L[i][k]*U[k][j];
            }
        }
    }
    for(i=0;i<n;i++){//A=L×U
        for(k=0;k<n;k++){
            A[i][k]=0;
            for(j=0;j<n;j++){
                A[i][k]+=L[i][j]*U[j][k];
            }
        }
    }
    printf("\n\nMatrix L:\n");// Output non-zero elements of matrix L.
    for(i=0;i<n;i++){
        for(k=0;k<9*max(0,i-r);k++) printf(" ");
        for(j=max(0,i-r);j<=i;j++){
            printf("%8.4lf ", L[i][j]);
        }
        printf("\n");
    }
    printf("\n\nMatrix U:\n");// Output non-zero elements of matrix U.
    for(i=0;i<n;i++){
        for(k=0;k<9*i;k++) printf(" ");
        for(j=i;j<=min(i+s,n-1);j++){
            printf("%8.4lf ", U[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<n && check;i++){
        for(j=0;j<n && check;j++){
            check=check && (fabs(A1[i][j]-A[i][j])<0.0001);// Compare A[i][j] and A1[i][j], allow error 0.0001.
        }
    }
    if(check) printf("The LU-decomposition program is correct.\n");
    else printf("The LU-decomposition program is incorrect.\n");
    return 0;
}
