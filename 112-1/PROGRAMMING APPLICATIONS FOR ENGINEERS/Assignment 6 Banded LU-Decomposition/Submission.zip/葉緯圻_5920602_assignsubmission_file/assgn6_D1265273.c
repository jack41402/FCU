#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int min(int x, int y)//write a function that find a minimum between two numbers
{
	if (x>y)
	{
		return y;
	}
	else 
	{
		return x;
	}
}

int max(int x, int y)//write a function that find a maximum between two numbers
{
	if (x>y)
	{
		return x;
	}
	else 
	{
		return y;
	}
}

void decomposition(int n,int lowerA, int upperA, float A[100][100], float L[100][100], float U[100][100]) 
//The function that calculate L, U and A-submatrix when doing LU decomposition
{
	int i, j, k;//define the loop variables	
	for (k=0; k<n; k++)
	{
		for (j=k; j<=min(n-1, k+upperA); j++)
		{
			U[k][j]= A[k][j];//compuute elements of the k-th row of matrix U
		}
		for (i=k; i<=min(n-1, k+lowerA); i++)
		{
			L[i][k]= A[i][k]/ A[k][k];//compute elements of the k-th column of matrix L
		}
		for (i=k+1; i<=min(n-1, k+lowerA); i++)
		{
			for (j=max(k+1, i-lowerA); j<=min(n-1, min(i+upperA, k+upperA)); j++)
			{
				A[i][j]=A[i][j]- L[i][k]* U[k][j];//compuate the submatrix A
			}
		} 
	}
}

int main(void)
{
  float A[100][100], B[100][100], C[100][100], C1[100][100]; // Assume four differents array that maximum 100 by 100 elements.
  int n; // Size of square matrices.
  int ra, sa; // Lower bandwidth and upper bandwidth of matrix A.
  int check; //define the check variable
  int i, j, k; // define the Loop variables.
  
  srand(time(NULL)); // Seed of the random number generator
  
  printf("Enter matrix size n: "); // Input the size of square matrices.
  scanf("%d", &n); 
  // Input lower bandwidth and upper bandwidth of matrix A.
  printf("\nEnter the lower bandwidth and upper bandwidth of matrix A, ra and sa: ");
  scanf("%d %d", &ra, &sa); 
    
   //intialize the four arrays to 0
   for (i=0; i<n; i++)
   {
   	for (j=0; j<n; j++)
   	{
   		A[i][j]=0;
   		B[i][j]=0;
   		C[i][j]=0;
   		C1[i][j]=0;
	}
   }
   
  for (i=0; i<n; i++)
  {
  	for (j=0; j<n; j++) 
  	{
  	 	A[i][j] = (rand() % 10000 + 1)/ 10000.0;// Randomly generate elements of A, between 0 and 1
  	 	C1[i][j]= A[i][j];// copy the elements of A array to array C1
	}
  }
  
   decomposition(n, ra, sa, A, B, C);//use function decomposition to calculate all the elements of L array and U array
   
   printf("\nMatrix A:\n");
   //print out the matrix A in banded format
   for (i=0; i<n; i++)
   {
		for (j=0; j<max(0, i-ra); j++)
		{
			printf("         ");//print 9 spaces when the random number is out of the range of ra and sa
		}
		for (j=max(0,i-ra); j<=min(n-1,i+sa); j++)
		{
			printf("%8.4f ", C1[i][j]);//print out the elements in banded format
		}
		printf("\n");//change to the next line whenever i plus 1
   } 
   
   printf("\nMatrix L:\n");
   //print the lower banded triangular matrix L
   for (i=0; i<n; i++)
   {
		for (j=0; j<max(0, i-ra); j++)
		{
			printf("         ");//print 9 spaces when the random number is out of the range of ra 
		}
   		for (j=max(0,i-ra); j<=min(n-1,i); j++)
   		{
   			printf("%8.4f ", B[i][j]);//print all the elements in a lower banded triangular matrix format
		}
		printf("\n");//change to the next line whenever i plus 1
   }
  
  printf("\nMatrix U:\n");
  //print the upper banded triangular matrix U
  for (i=0; i<n; i++)
  {
  	for (j=0; j<i; j++)
  	{
  		printf("         ");//print 9 spaces when the random number is out of the range of sa
	}
	for (j=i; j<=min(n-1, i+sa); j++)
	{
		printf("%8.4f ", C[i][j]);//print all the wlwments in a upper banded triangular matrix format
	}
	printf("\n");//change to the next line whenever i plus 1
  }
  
  //initialize matrix A to 0
  for (i=0; i<n; i++)
  {
  	for (j=0; j<n; j++)
  	{
  		A[i][j]= 0;
	}
  }
  
  //verify
  check= 1;//define check variable to 1
  //calaulate maxtrix A to the result of matrix B times matrix C
  for (i=0; i<n ; i++)
  {
  	for (j=0; j<n ; j++)
  	{
  		
  		for (k=0; k<n; k++)
  		{
  			A[i][j]+= B[i][k]* C[k][j];	
		}
	}
  }
  //check the error of every elements in banded format compared to C1
  for (i=0; i<n && check; i++)
  {
  	for (j=max(0, i-ra); j<=min(n-1, i+sa) && check; j++)
  	{
  		check = check && (fabs(A[i][j]-C1[i][j])<0.0001);
	}
  }
  
  printf("\n");
  
  //check if variable check is 1 or not, if yes, the LU-decomposition is correct, if not, the LU-deconposition is incorrect
  if (check)
  {
  	printf("\nThe LU-decomposition program is correct.\n");
  }
  else 
  {
  	printf("\nThe LU-decomposition program is incorrect.\n");
  }
  return 0;
}
