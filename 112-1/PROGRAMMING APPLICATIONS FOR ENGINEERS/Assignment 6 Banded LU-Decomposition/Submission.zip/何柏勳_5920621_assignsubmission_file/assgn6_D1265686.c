
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

// Return minimum vlaue of x and y.
int min(int x, int y) {
  if (x<y) return x;
  else return y;
}

// Return maximum vlaue of x and y.
int max(int x,int y){
    if(x<y)return y;
    else return x;
}



void LU_decompose(int n, float A[100][100], float L[100][100], float U[100][100] ,int s, int r ) {
  int i, j, k;
  // Perform LU decomposition
  for (k=0; k<n; k++) {
    for (j=k; j <= min(n-1,k+s); j++) U[k][j] = A[k][j];
    for (i=k; i<=min(n-1,k+r); i++) L[i][k] = A[i][k] / A[k][k];
    for (i=k+1; i<=min(n-1,k+r); i++)
      for (j=max(k+1,i-r); j<=min(n-1,min(i+s,k+s)); j++) A[i][j] = A[i][j] - L[i][k] * U[k][j];
  }
}

int main(void) {
    float A[100][100], A1[100][100], L[100][100], U[100][100]; // Assume maximum 100 by 100 elements.
    int n; // Size of the square matrices.
    int check; // Flag to check the correctness of the program.
    int i, j, k; // Loop variables.
    int r,s;
    srand(time(NULL)); // Seed of the random number generator.
    
    printf("Enter matrix size n: "); // Input the matrix size.
    scanf("%d", &n);
    printf("\nEnter the lower bandwidth and the upper bandwidth of matrix A, (r, s): ");
    scanf("%d %d", &r, &s);
    
    // Get values for the elements of matrix A.
    // Matrix element A[i][j], 0<A[i][j]<=1; A1[i][j] is the copy of A[i][j] for program verification.
    for (i=0; i<n; i++)
        for (j=0; j<n; j++) {A[i][j] = (rand() % 10000 + 1) / 10000.0; A1[i][j] = A[i][j];}
    
    printf("\nMatrix A:\n");// Output matrix A.
    
    for (i=0; i<n; i++) {
        for (j=0; j<n; j++)
        {
            if(0<i-j && (i-j)<=r)
            {
                printf("%8.4f ", A[i][j]);
            }
            else if(0<j-i && (j-i)<=s)
            {
                printf("%8.4f ",A[i][j]);
            }
            else if(i==j)
            {
                printf("%8.4f ",A[i][j]);
            }
            else{
                printf("         ");
            }
            
        }
        printf("\n");
    }
    
    LU_decompose(n, A, L, U ,s ,r); // Peform LU-decomposition.
    
    printf("\nMatrix L:\n"); // Output matrix L.
    for (i=0; i<n; i++) {
        for (k=0; k<n; k++)
        {
            if(k<=i && i<=min(n-1,k+r))
            {
                printf("%8.4f ", L[i][k]);
            }
            else
            {
                printf("         ");
            }
        }
        printf("\n");
    }
    
    printf("\nMatrix U:\n"); // Ouput matrix U.
    for (k=0; k<n; k++) {
        for (j=0; j<n; j++)
        {
            if(k<=j && j<=min(n-1, k+s))
            {
                printf("%8.4f ", U[k][j]);
            }
            else
            {
                printf("         ");
            }
        }
        printf("\n");
    }
  
  check = 1; // Intial flag to true.
  for (i=0; i<n && check; i++)
    for (j=max(0,i-r); j<=min(n-1,i+s) && check; j++) {
      A[i][j] = 0;
      for (k=max(0, max(i-r,j-s)); k<=min(n-1,min(i,j)); k++) A[i][j] += L[i][k] * U[k][j];
      check = check && (fabs(A[i][j]-A1[i][j])<0.0001); // Compare A[i][j] and A1[i][j], allow error 0.0001.
    }
  if (check) printf("\nThe LU-decomposition program is correct.\n"); // The program is correct.
  else printf("\nThe LU-decomposition program is incorrect.\n"); // The program is incorrect.
  
  return 0;
    
}


