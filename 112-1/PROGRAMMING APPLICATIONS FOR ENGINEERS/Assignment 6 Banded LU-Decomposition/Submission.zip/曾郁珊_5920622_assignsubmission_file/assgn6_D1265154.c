#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
// Function to perform LU decomposition of a matrix A into L and U.
void LU_decompose(int, float A[][100], float L[][100], float U[][100]);
// Function to check the correctness of the LU decomposition.
int check(int,float A1[][100], float L[][100], float U[][100]);
// Function to return the minimum value between x and y.
int min(int, int);


int main(void) {
	srand(time(NULL));// Seed for the random number generator.
	// Declaration and initialization of matrices A, L, U, and A1.
	float A[100][100]={0}, L[100][100]={0}, U[100][100]={0}, A1[100][100]={0};
	int n, r, s; // Variables for matrix size, lower bandwidth (r), and upper bandwidth (s).
	int i, j, k;
	printf("Enter matrix size n: ");// Prompt for the size of the matrix.
	scanf("%d", &n);
	do// Loop to ensure valid values for lower and upper bandwidth.
	{
		printf("Enter the lower and upper bandwidth of matrix (r , s): ");
		scanf("%d %d", &r, &s);
	}while(r>n-1||s>n-1);
	 // Randomly generate elements for matrix A based on bandwidths.
	for(i=0;i<n;i++)
	{	// Generate elements in the upper bandwidth.
		for(j=0;j<=s;j++) if((i+j)<=(n-1)) A[i][i+j]=(rand()%10000+1) / 10000.0;
		 // Generate elements in the lower bandwidth.
		for(k=1;k<=r;k++) if((i-k)>=0) A[i][i-k]=(rand()%10000+1) / 10000.0;
	}
	 // Copy the original matrix A for later comparison.
	for(i=0;i<n;i++) 
		for(j=0;j<n;j++) A1[i][j]=A[i][j];
	// Perform LU decomposition.	
	LU_decompose(n, A, L, U);
	 // Output original matrix A.
	printf("\nMatrix A:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(A[i][j]==0)printf("         ");
			else printf("% 8.4f ", A1[i][j]);
		}
		printf("\n");
	}
	// Output lower triangular matrix L.
	printf("\nMatrix L:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(A[i][j]==0)printf("         ");
			else printf("% 8.4f ", L[i][j]);
		}
		printf("\n");
	}
	 // Output upper triangular matrix U.
	printf("\nMatrix U:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(A[i][j]==0)printf("         ");
			else printf("% 8.4f ", U[i][j]);
		}
		printf("\n");
	} 
	 // Check and print the correctness of the LU decomposition.
	if(check(n, A1, L, U)) printf("\nThe LU-decomposition program is correct.\n"); 
  	else printf("\nThe LU-decomposition program is incorrect.\n"); 
	
	return 0; 
}
// Implementation of LU decomposition algorithm.
void LU_decompose(int n, float A[][100], float L[][100], float U[][100]) {
	int i, j, k;
	for (k=0; k<n; k++) 
	{ // Outer loop for each step of the LU decomposition.
	// Copy elements from the original matrix A to the upper triangular matrix U.
		for (j=k; j<n; j++) U[k][j] = A[k][j]; 
		for (i=k; i<n; i++) L[i][k] = A[i][k] / A[k][k]; // Compute the elements of the lower triangular matrix L.
		for (i=k+1; i<n; i++) // Update the remaining elements in A based on the LU decomposition formula.
    		for (j=k+1; j<n; j++) A[i][j] = A[i][j] - L[i][k] * U[k][j];
	}
}
// Function to check the correctness of the LU decomposition.
int check(int n,float A1[][100], float L[][100], float U[][100])
{
	int i, j, k;// Variables for loop counters and a temporary sum.
	float sum;
	for(i=0;i<n;i++) // Loop over rows of A1, L, and U matrices.
	{// Loop over columns of A1, L, and U matrices.
		for(j=0;j<n;j++)
		{
			sum=0; // Initialize sum for the dot product calculation.
			for(k=0;k<=min(i,j);k++) sum += L[i][k]*U[k][j];// Calculate the dot product of L row and U column.
			if(fabs(A1[i][j]-sum)>=0.0001) return 0;
		}// Compare the original matrix A1 with the reconstructed matrix (L * U).
            // If the absolute difference is greater than or equal to 0.0001, return 0 (incorrect).
	}
	return 1;// If all comparisons pass, return 1 (correct).
}
// Function to return the minimum value between x and y.
int min(int x, int y) 
{
  if (x<y) return x;
  else return y;
}
