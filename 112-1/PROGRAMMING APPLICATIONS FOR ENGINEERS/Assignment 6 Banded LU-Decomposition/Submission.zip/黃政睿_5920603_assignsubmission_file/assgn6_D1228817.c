//D1228817
#include<stdio.h>
#include <math.h>

int i, j, k;

int max(int x, int y){// Return maximum value of x and y.
	if(x>y) return x;
	else return y;
}

int min(int x, int y){// Return minimum vlaue of x and y.
	if(x<y) return x;
	else return y;
}

void Create_Matrix_A(float A[100][100], int n){// Creates both the banded and non-banded elements of matrix A.
	srand(time(NULL));
	for(i=0; i<n; i++){
		for(j=0; j<n; j++){
			A[i][j]=(rand()%10000+1)/10000.0;
		}
	}
}

void Banded_LU_Decomposition(float A[100][100], float L[100][100], float U[100][100], int s, int r, int n){
	
	for(i=0; i<n; i++){
		for(j=0; j<n; j++){
			L[i][j]=0;// Set initial value of L[i][j] to 0.
			U[i][j]=0;// Set initial value of U[i][j] to 0.
		}
	}
	for(k=0; k<=n-1; k++){// Compute the values of L[i][j] and U[i][j] according to the given formula.
		for(j=k; j<=min(n-1, k+s); j++) U[k][j]=A[k][j];
		for(i=k; i<=min(n-1, k+r); i++) L[i][k]=A[i][k]/A[k][k];
		for(i=k+1; i<=min(n-1, k+r); i++){
			for(j=max(k+1, i-r); j<=min(n-1, min(i+s, k+s)); j++){
				A[i][j]=A[i][j]-L[i][k]*U[k][j];
			}
		}
	}
}

int Verification(float A[100][100], float A1[100][100], float L[100][100], float U[100][100], int n, int s, int r){

int flag=1;// Set initial value of flag to 1(true).

	for(i=0; i<n; i++){
		for(j=0; j<n; j++){
			A[i][j]=0;
			if(max(0,i-r)<=j&&j<=min(n-1,i+s)){// Check only the banded elements.
				for(k=0; k<n; k++){
					A[i][j]+=L[i][k]*U[k][j];
				}
				if(fabs(A[i][j]-A1[i][j])>0.0001) flag=0;// Set flag to 0(false) if A[i][j]!=A1[i][j].
			}
		}
	}

return flag;
}

int main(){
	
float A[100][100];
float A1[100][100];
float L[100][100];
float U[100][100];
int n, s, r;// n=size of matrix A, s=upper bandwidth of A, r=lower bandwidth of A.	

printf("Enter matrix size n: ");
scanf("%d", &n);
printf("\nEnter the lower bandwidth and the upper bandwidth of matrix A, (r, s): ");
scanf("%d %d", &r, &s);

Create_Matrix_A(A, n);

printf("\nMatrix A:\n");
for(i=0; i<n; i++){// Print matrix A.
	for(j=0; j<n; j++){
		if(0<i-j&&i-j<=r) printf("%8.4f ", A[i][j]);// Print lower band elements.
		else if(0<j-i&&j-i<=s) printf("%8.4f ", A[i][j]);// Print upper band elements.
		else if(i==j) printf("%8.4f ", A[i][j]);// Print diagonal elements.
		else printf("         ");
	}
	printf("\n");
}

for(i=0; i<n; i++){// Make a copy of all the elements in A and store them in A1.
	for(j=0; j<n; j++){
		A1[i][j]=A[i][j];
	}
}

Banded_LU_Decomposition(A, L, U, s, r, n);

printf("\nMatrix L:\n");
for(i=0; i<n; i++){// Print matrix L.
	for(k=0; k<n; k++){
		if(k<=i&&i<=min(n-1,k+r)) printf("%8.4f ", L[i][k]);// Print the non-zero elements.
		else printf("         ");
	}
	printf("\n");
}

printf("\nMatrix U:\n");
for(k=0; k<n; k++){// Printf matrix U.
	for(j=0; j<n; j++){
		if(k<=j&&j<=min(n-1, k+s)) printf("%8.4f ", U[k][j]);// Print the non-zero elements.
		else printf("         ");
	}
	printf("\n");
}

if(Verification(A, A1, L, U, n, s, r)==1) printf("\nThe LU-decomposition program is correct.");
else printf("\nThe LU-decomposition program is not correct.");

return 0;
}
