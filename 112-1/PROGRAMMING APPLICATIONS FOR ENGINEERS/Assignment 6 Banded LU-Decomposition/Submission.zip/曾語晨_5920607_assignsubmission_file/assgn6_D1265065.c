//
//  main.c
//  assignment6
//
//  Created by Corrine  on 2023/12/10.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
// Return maximum vlaue of x and y.
int max(int x, int y)
{
    if(x>y) return x;
    else return y;
}
// Return minimum vlaue of x and y.
int min(int x, int y)
{
    if(x<y) return x;
    else return y;
}
// Print out the matrix.
int printMatrix(int a, int b, float Matrix[100][100])
{
    int i, j;
    for(i = 0; i < a; i++)
    {
        for(j = 0; j < b; j++)
        {
            if(Matrix[i][j]==0) printf("        ");
            else printf("%8.4f", Matrix[i][j]);
        }
        printf("\n");
    }
    return Matrix;
}

int main(void) {
    float A[100][100], A1[100][100], L[100][100], U[100][100]; // Assume maximum 100 by 100 elements.
    int i, j, k; // Loop variables.
    int n, r, s; // Matrix variables.
    int check; // Variables use to check if the calculation is correct.
    printf("Enter matrix size n: ");
    scanf("%d", &n); // Input the matrix size.
    printf("\nEnter the lower bandwidth and the of matrix A, (r, s): ");
    scanf("%d %d", &r, &s); // Input the lower bandwith and upper bandwith of matrix A
    srand(time(NULL)); // Seed of the random number generator.
    // Loop for matrix A
    for(i = 0; i < n; i++)
    {
        for(j = max(0, i-r); j <= min(n-1, i+s); j++)
        {
            A[i][j] = (rand() % 10000 + 1) / 10000.0; // Randomly generate elements of A, between 0 between 0.0001.
            A1[i][j] = A[i][j]; // Matrix element A[i][j], 0<A[i][j]<=1; A1[i][j] is the copy of A[i][j] for program verification.
        }
    }
    printf("\nMatrix A:\n");
    printMatrix(n, n, A); // Print out the Matrix A.
    // Peform LU-decomposition.
    for(k = 0; k < n; k++)
    { // To compute submatrix A(k+1).
        for(j = k; j <= min(n-1, k+s); j++)
        {
            U[k][j] = A[k][j]; // Compute elements of the k-th row of matrix U
        }
        for(i = k; i <= min(n-1, k+r); i++)
        {
            L[i][k] = A[i][k]/A[k][k]; // Compute elements of the k-th column of matrix L
        }
        for(i = k+1; i <= min(n-1, k+r); i++)
        { // Compute elements of submatrix A(k+1)
            for(j = max(k+1, i-r); j <= min(n-1, min(i+s, k+s)); j++)
            {
                A[i][j] = A[i][j]-L[i][k]*U[k][j];
            }
        }
    }
    printf("\nMatrix L:\n");
    printMatrix(n, n, L); // Print out the Matrix L.
    printf("\nMatrix U:\n");
    printMatrix(n, n, U); // Print out the Matrix U.
    
    check = 1; // Intial flag to true.
    for(i = 0; i < n && check; i++)
    {
        for(j = 0; j < n && check; j++)
        {
            A[i][j] = 0;
            for(k = 0; k <= min(i, j); k++)
            {
                A[i][j] += L[i][k] * U[k][j]; // Compute A[i][j] for A<=LU
            }
            check = check && (fabs(A[i][j]-A1[i][j])<0.0001); // Compare A[i][j] and A1[i][j], allow error 0.0001.
           // if (!check) printf("\n\nA[%d][%d]=%f\n\n", i, j, A[i][j]);
        }
    }
    if(check) printf("\nThe LU-decomposition program is correct.\n"); // The program is correct.
    else printf("\nThe LU-decomposition program is incorrect.\n"); // The program is incorrect.
    return 0;
}
