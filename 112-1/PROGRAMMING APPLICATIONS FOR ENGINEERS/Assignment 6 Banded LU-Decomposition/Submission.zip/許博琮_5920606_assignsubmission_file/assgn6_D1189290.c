#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h> 

// Function to return the maximum of two integers
int max(int a, int b){  
	return a > b ? a : b;
}

// Function to return the minimum of two integers
int min(int a, int b){  
	return a > b ? b : a;
}

// Function to perform LU decomposition of the matrix A
void LU_decompose(int n, int r, int s, float A[100][100], float L[100][100], float U[100][100]){  
	int i, j, k;
	for(k = 0; k < n; k++){
		for(j = k; j <= min(n - 1, k + s); j++) 
			U[k][j] = A[k][j]; // Compute elements of the k-th row of matrix U
		
		for(i = k; i <= min(n - 1, k + r); i++) 
			L[i][k] = A[i][k] / A[k][k]; // Compute elements of the k-th column of matrix L
		
		for(i = k + 1; i <= min(n - 1, k + r); i++){
			for(j = max(k + 1, i - r); j <= min(n - 1, min(i + s, k + s)); j++) 
				A[i][j] = A[i][j] - L[i][k] * U[k][j]; // Compute elements of submatrix A(k+1)
		}
	}
}

int main(){	
	int n, r, s, check, i, j, k;
	float A[100][100], A1[100][100], L[100][100], U[100][100];
	
	srand(time(NULL)); // Seed for random number generation
	
	printf("Enter matrix size n: "); 
	scanf("%d", &n);
	printf("\nEnter the lower bandwidth and the upper bandwidth of matrix A, (r,s): ");
	scanf("%d %d", &r, &s);
	
	// Generate random non-banded elements for matrix A
	for(i = 0; i < n; i++){   
		for(j = max(0, i - r); j <= min(n - 1, i + s); j++){
			A[i][j] = (rand() % 10000 + 1) / 10000.0; // Random values between 0 and 1
			A1[i][j] = A[i][j]; // Copying A to A1 for verification
		}
	}
	
	printf("\nMatrix A:\n");
	// Printing matrix A
	for(i = 0; i < n; i++){
		for(j = 0; j < max(0, i - r); j++) printf("         ");
		for(j = max(0, i - r); j <= min(n - 1, i + s); j++) printf("%8.4f ", A[i][j]);
		printf("\n");
	}
	
	// Perform LU decomposition
	LU_decompose(n, r, s, A, L, U);
	
	printf("\nMatrix L:\n");
	// Printing matrix L
	for(i = 0; i < n; i++){
		for(j = 0; j < max(0, i - r); j++) printf("         ");
		for(j = max(0, i - r); j <= i; j++) printf("%8.4f ", L[i][j]);
		printf("\n");
	}
	
	printf("\nMatrix U:\n");
	// Printing matrix U
	for(i = 0; i < n; i++){
		for(j = 0; j < i; j++) printf("         ");
		for(j = i; j <= min(n - 1, i + s); j++) printf("%8.4f ", U[i][j]);
		printf("\n");
	}
	
	// Verification step to check if A = L * U
	check = 1;
	for(i = 0; i < n && check; i++){
		for(j = 0; j < n && check; j++){
			A[i][j] = 0;
			for(k = 0; k <= min(i, j); k++) A[i][j] += L[i][k] * U[k][j];
			check = check && (fabs(A[i][j] - A1[i][j]) < 0.0001); // Tolerance check
		}
	}
	
	// Output the result of verification
	if(check) printf("\nThe LU-decomposition program is correct.\n");
	else printf("\nThe LU-decomposition program is incorrect.\n");
}

