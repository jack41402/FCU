#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int max(int x, int y){//Return the maximum one of x and y
	if (x > y) return x;
	else return y;
}

int min(int x, int y){//Return the minimum one of x and y
	if (x > y) return y;
	else return x;
}

//Decompoition function
void decomposition(int n,int lowerA, int upperA, float A[100][100], float L[100][100], float U[100][100]) {
	int i, j, k;
	for (k=0; k<n; k++){
		for (j=k; j<=min(n-1, k+upperA); j++)U[k][j]= A[k][j];
		for (i=k; i<=min(n-1, k+lowerA); i++)L[i][k]= A[i][k]/ A[k][k];
		for (i=k+1; i<=min(n-1, k+lowerA); i++){ 
			for (j=max(k+1, i-lowerA); j<=min(n-1, (i+upperA, k+upperA)); j++)
				A[i][j]= A[i][j]- L[i][k]* U[k][j];
		} 
	}
}

int main(void){
   
  	float A[100][100] = {}, L[100][100] = {}, U[100][100] = {}, K[100][100] = {}; 
   	int n; //The size of matrixs
   	int ra, sa; //Lower bandwidth and upper bandwidth of matrix A.
   	int verify; //Define the variable for verify
   	int i, j, k; //Define the Loop variables.
  	
	//Input variable n
	printf("Enter matrix size n: "); 
   	scanf("%d", &n); 
   	
	//Input lower bandwidth and upper bandwidth of matrix A.
   	printf("\nEnter the lower bandwidth and upper bandwidth of matrix A, (r, s): ");
   	scanf("%d %d", &ra, &sa); 
   	
	srand(time(NULL)); //Seed of the random number generator
    
   	for (i=0; i<n; i++){
  		for (j=0; j<n; j++){
  	 		A[i][j] = (rand() % 10000 + 1)/ 10000.0;//Generate the numbers in array A ramdomly
  	 		K[i][j] = A[i][j];//Copy the numbers of array A to array C1
		}
  	}
	//Use the decomposition function to calculate all the numbers in L and U arrays
   	decomposition(n, ra, sa, A, L, U);
   	
	//Print matrix A
  	printf("\nMatrix A:\n");
  	for (i=0; i<n; i++){
  		//Print 9 spaces when the random number is out of the range of ra and sa
		for (j=0; j<max(0, i-ra); j++){
			printf("         ");
		}
		//Print out the numbers in banded format
		for (j=max(0,i-ra); j<=min(n-1,i+sa); j++){
			printf("%8.4f ", K[i][j]);
		}
		printf("\n");
   	} 
    
	//Print matrix L
  	printf("\nMatrix L:\n");
   	for (i=0; i<n; i++){
   		//Print 9 spaces when the random number is out of the range of ra 
		for (j=0; j<max(0, i-ra); j++){
			printf("         ");
		}
		//Print all the numbers in a lower banded triangular matrix format
   		for (j=max(0,i-ra); j<=min(n-1,i); j++){
   			printf("%8.4f ", L[i][j]);
		}
		printf("\n");
   	}
    
	//Print matrix U
  	printf("\nMatrix U:\n");
  	for (i=0; i<n; i++){
  		//Print 9 spaces when the random number is out of the range of sa
  		for (j=0; j<i; j++){
  			printf("         ");
		}
		//Print all the numbers in a upper banded triangular matrix format
		for (j=i; j<=min(n-1, i+sa); j++){
			printf("%8.4f ", U[i][j]);
		}
		printf("\n");
  	}
  	
  	for (i=0; i<n; i++){
  		for (j=0; j<n; j++){
  			A[i][j]= 0;
		}
  	}
  	
  	//Calaulate maxtrix A to the result of matrix L times matrix K
  	for (i=0; i<n ; i++){
  		for (j=0; j<n ; j++){	
  			for (k=0; k<n; k++){
  				A[i][j] += L[i][k] * U[k][j];	
			}
		}
  	}
  	//Verify
  	verify= 1;//Set the verify variable to 1
  	for (i=0; i<n && verify; i++){
  		for (j=max(0, i-ra); j<=min(n-1, i+sa) && verify; j++){
  			verify = verify && (fabs (A[i][j] - K[i][j]) < 0.0001);
		}
  	}
  	printf("\n\n");
  	//Print the result of verify
  	if (verify==1)printf("\nThe LU-decomposition program is correct.\n"); 
  	else printf("\nThe LU-decomposition program is incorrect.\n");
 return 0;
}
