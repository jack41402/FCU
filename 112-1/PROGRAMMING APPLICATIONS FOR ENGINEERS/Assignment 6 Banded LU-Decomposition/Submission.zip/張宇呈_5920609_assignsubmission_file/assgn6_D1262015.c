#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int max(int x, int y) {
    if (x > y)
        return x;
    else
        return y;
}

int min(int x, int y) {
    if (x < y)
        return x;
    else
        return y;
}

void LU_decompose(int n, int r, int s, float A[100][100], float L[100][100], float U[100][100]) {
    int i, j, k;

    for (k = 0; k < n; k++) {
        for (j = k; j <= min(n - 1, k + s); j++)
            U[k][j] = A[k][j];

        for (i = k; i <= min(n - 1, k + r); i++)
            L[i][k] = A[i][k] / A[k][k];

        for (i = k + 1; i <= min(n - 1, k + r); i++)
            for (j = max(k + 1, i - r); j <= min(n - 1, min(i + s, k + s)); j++)
                A[i][j] = A[i][j] - L[i][k] * U[k][j];
    }
}

int main(void) {
    float A[100][100], A1[100][100], L[100][100], U[100][100];
    int n, r, s;
    int check;
    int i, j, k;

    srand(time(NULL));

    printf("Enter square matrix size n: ");
    scanf("%d", &n);
    printf("Enter the lower bandwidth and the upper bandwidth of matrix A, (r, s): ");
    scanf("%d %d", &r, &s);

    for (i = 0; i < n; i++)
        for (j = max(0, i - r); j <= min(n - 1, i + s); j++) {
            A[i][j] = (rand() % 10000 + 1) / 10000.0;
            A1[i][j] = A[i][j];
        }

    printf("\nMatrix A:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < max(0, i - r); j++)
            printf("         ");

        for (j = max(0, i - r); j <= min(n - 1, i + s); j++)
            printf("%8.4f ", A[i][j]);

        printf("\n");
    }

    LU_decompose(n, r, s, A, L, U);

    printf("\nMatrix L:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < max(0, i - r); j++)
            printf("         ");

        for (j = max(0, i - r); j <= i; j++)
            printf("%8.4f ", L[i][j]);

        printf("\n");
    }

    printf("\nMatrix U:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < i; j++)
            printf("         ");

        for (j = i; j <= min(n - 1, i + s); j++)
            printf("%8.4f ", U[i][j]);

        printf("\n");
    }

    check = 1;
    for (i = 0; i < n && check; i++)
        for (j = max(0, i - r); j <= min(n - 1, i + s) && check; j++) {
            A[i][j] = 0;
            for (k = max(0, max(i - r, j - s)); k <= min(n - 1, min(i, j)); k++)
                A[i][j] += L[i][k] * U[k][j];

            check = check && (fabs(A[i][j] - A1[i][j]) < 0.0001);
        }

    if (check)
        printf("\nThe LU-decomposition program is correct.\n");
    else
        printf("\nThe LU-decomposition program is incorrect.\n");

    return 0;
}

