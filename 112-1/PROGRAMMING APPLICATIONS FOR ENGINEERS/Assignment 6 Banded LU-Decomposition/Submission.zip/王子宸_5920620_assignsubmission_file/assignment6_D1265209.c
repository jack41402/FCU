#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define MAX_SIZE 100// Define a constant for the maximum size of matrices
// Function to find the minimum of two integers
int min(int x, int y) {
    if (x < y) return x;
    else return y;
}
// Function to find the maximum of two integers
int max(int x, int y){
    if(x > y) return x;
    else return y;
}
// Function to calculate the product of banded matrices
void matrix_product_banded(int n, int r, int s, double A[MAX_SIZE][MAX_SIZE], double A1[MAX_SIZE][MAX_SIZE]) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            // Apply conditions to determine if the element should be set to 0
            if (i - j > r || j - i > s) {
                A[i][j] = 0.0;// Set the element to 0 if it's outside the band
            } else {
                // Assign a random value to A[i][j] if it's inside the band
                A[i][j] = (rand() % 10000 + 1) / 1000.0;
            }
            // Copy the value of A[i][j] to A1[i][j]
            A1[i][j] = A[i][j];
        }
    }
}
// Function to print a matrix of size n x n
void printMatrix(int n, double A[MAX_SIZE][MAX_SIZE]) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            // Print non-zero elements with formatting
            if (A[i][j] != 0.0) {
                printf("%8.4f", A[i][j]);
            } else {
                // Print spaces for zero elements for better readability
                printf("         ");
            }
        }
        printf("\n");
    }
}
// Begin the declaration of the LU_decompose function
void LU_decompose(int n, int r, int s, double A[MAX_SIZE][MAX_SIZE], double L[MAX_SIZE][MAX_SIZE], double U[MAX_SIZE][MAX_SIZE]) {
    int i, j, k;
    for (k = 0; k < n; k++) {
        // Calculate the upper triangular matrix U
        for (j = k; j < n && j <= k + s; j++) {
            U[k][j] = A[k][j];
        }
        // Calculate the lower triangular matrix L
        for (i = k; i < n && i <= k + r; i++) {
            L[i][k] = A[i][k] / A[k][k];
        }
        // Update the remaining elements in the matrix A
        for (i = k + 1; i < min(n, k+r); i++) {
            for (j = max(k+1, i-r); j < min(n, min(i+s, k+s)); j++) {
                A[i][j] -= L[i][k] * U[k][j];
            }
        }
    }
}

int main(void) {
    double A[MAX_SIZE][MAX_SIZE], A1[MAX_SIZE][MAX_SIZE], L[MAX_SIZE][MAX_SIZE], U[MAX_SIZE][MAX_SIZE];
    int n, r, s;
    int i, j, k;
    srand(time(NULL));// Seed the random number generator
    printf("Enter matrix size n: ");// Input the size of the matrix
    scanf("%d", &n);
    printf("Enter the lower bandwidth and the of maxtrix A, (r, s): ");// Input the bandwidths for the matrix
    scanf("%d %d", &r, &s);
    matrix_product_banded(n, r, s, A, A1);// Generate a banded matrix A and copy it to A1
    printf("Matrix A: \n");//Print the generated matrix A
    printMatrix(n, A);
    LU_decompose(n, r, s, A, L, U);// Decompose matrix A into L and U
    printf("\nMatrix L:\n");// Print the lower triangular matrix L
    printMatrix(n, L);
    printf("\nMatrix U:\n");// Print the upper triangular matrix U
    printMatrix(n, U);

    int check = 1; // Intial flag to true. 
    for (i=0; i<n && check; i++)
        for (j=0; j<n && check; j++) {
            A[i][j] = 0;
            // Compute the product of L and U to verify the decomposition
            for (k=0; k<=min(i,j); k++) 
                A[i][j] += L[i][k] * U[k][j]; // Compute A[i][j] for A<=LU 
            check = check && (fabs(A[i][j]-A1[i][j])<0.0001); // Compare A[i][j] and A1[i][j], allow error 0.0001.
        }
  
    if (check) printf("\nThe LU-decomposition program is correct.\n"); // The program is correct.
    else printf("\nThe LU-decomposition program is incorrect.\n"); // The program is incorrect.

    return 0;
}