#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int min(int a, int b){
	if (a < b) return a;
	else return b;
}

int max(int a, int b){
	if (a > b) return a;
	else return b;
}

int main(void){
	int i, j, k;
	int r, s, n;
	float A[100][100] = {}, L[100][100] = {}, U[100][100] = {}, A1[100][100];//A=LU
	
	//input
	printf("Enter the matrix size n: ");
	scanf("%d", &n);
	printf("Enter the lower bandwidth and the upper bandaidth of matrix A(r,s): ");
	scanf("%d %d", &r, &s);
	
	srand(time(NULL));
	
	//create banded matrix A
	for(i=0; i<n; i++){
		for(j=0; j<n; j++){
			A[i][j] = (rand()%10001) / 10000.0;//make sure to put decimal point
			A1[i][j] = A[i][j];
		}
	}

	//LU decomposition
	for(k=0; k<n; k++){
		for(j=k; j<=min(n-1, k+s); j++){
			U[k][j] = A[k][j];
		}
		for(i=k; i<=min(n-1, k+r); i++){
			L[i][k] = A[i][k]/A[k][k];
		}
		for(i=k+1; i<=min(n-1, k+r); i++){
			for(j=k+1; j<=min(n-1, k+s); j++){
				A[i][j] = A[i][j] - L[i][k] * U[k][j];
			}
		}
	}
	
	//verify
	int flag = 1;
	for(i=0; i<n && flag; i++){
		for(j=max(0, i-r); j<=min(n-1, i+s) && flag; j++){
			A[i][j] = 0;
			for(k=0; k<n; k++){
				A[i][j] += L[i][k] * U[k][j];
			}
			flag = flag && (fabs(A[i][j]-A1[i][j]<0.0001)); 
		}
	}
	
	//output
	printf("\nMatrix A: \n");
	for(i=0; i<n; i++){
    	for (k=0; k<max(0,i-r); k++){
    		printf("         "); 	
		} 
		for(j=max(0, i-r); j<=min(n-1, i+s); j++){
			printf("%8.4f ", A1[i][j]);
		}
		printf("\n");
	}

	printf("\nMatrix L: \n");
	for(i=0; i<n; i++){
    	for (k=0; k<max(0, i-r); k++){
    		printf("         "); 	
		} 
		for(j=max(0, i-r); j<=i; j++){
			printf("%8.4f ", L[i][j]);
		}
		printf("\n");
	}	

	printf("\nMatrix U: \n");
	for(i=0; i<n; i++){
    	for (k=0; k<i; k++){
    		printf("         "); 	
		} 
		for(j=i; j<=min(n-1, i+s); j++){
			printf("%8.4f ", U[i][j]);
		}
		printf("\n");
	}
	
	if(flag) printf("The LU-decomposition program is correct.\n");
    else printf("The LU-decomposition program is incorrect.\n");	
}
