#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>

// Function to get the minimum of two integers
int min(int a, int b){
	if (a < b) return a;
	else return b;
}

// Function to get the maximum of two integers
int max(int a, int b){
	if (a > b) return a;
	else return b;
}

int main(void){
	int i, j, k;
	int r, s, n;
	float **A, **L, **U, **A1; // Define matrix pointers A, L, U, A1 for LU decomposition
	
	// Input matrix size and lower & upper bandwidth
	printf("Enter the matrix size n: ");
	scanf("%d", &n);
	printf("Enter the lower bandwidth and the upper bandwidth of matrix A(r, s): ");
	scanf("%d %d", &r, &s);
	
	srand(time(NULL)); // Seed for random number generation
	
	// Memory allocation for matrices
	A = (float**) malloc(sizeof(float*) * n);
	L = (float**) malloc(sizeof(float*) * n);
	U = (float**) malloc(sizeof(float*) * n);
	A1 = (float**) malloc(sizeof(float*) * n);
	for(i = 0; i < n; i++){
		A[i] = (float*) malloc(sizeof(float) * (min(i, r) + 1 + min(n - 1 - i, s)));
		L[i] = (float*) malloc(sizeof(float) * (min(i, r) + 1));
		U[i] = (float*) malloc(sizeof(float) * (min(n - i, s + 1)));
		A1[i] = (float*) malloc(sizeof(float) * (min(i, r) + 1 + min(n - 1 - i, s)));
	}
	
	// Create banded matrix A with random values
	for(i = 0; i < n; i++){
		for(j = 0; j < n; j++){
			A[i][j] = (rand() % 10001) / 10000.0; // Ensure to use decimal point in the generated random numbers
			A1[i][j] = A[i][j]; // Copy matrix A to A1 for verification
		}
	}

	// LU decomposition
	for(k = 0; k < n; k++){
		for(j = k; j <= min(n - 1, k + s); j++){
			U[k][j] = A[k][j];
		}
		for(i = k; i <= min(n - 1, k + r); i++){
			L[i][k] = A[i][k] / A[k][k];
		}
		for(i = k + 1; i <= min(n - 1, k + r); i++){
			for(j = k + 1; j <= min(n - 1, k + s); j++){
				A[i][j] = A[i][j] - L[i][k] * U[k][j];
			}
		}
	}
	
	// Verification of LU decomposition
	int flag = 1;
	for(i = 0; i < n && flag; i++){
		for(j = max(0, i - r); j <= min(n - 1, i + s) && flag; j++){
			A[i][j] = 0;
			for(k = 0; k < n; k++){
				A[i][j] += L[i][k] * U[k][j];
			}
			flag = flag && (fabs(A[i][j] - A1[i][j]) < 0.0001); // Compare A and A1
		}
	}
	
	// Output matrices A, L, U
	printf("\nMatrix A: \n");
	for(i = 0; i < n; i++){
		for(k = 0; k < max(0, i - r); k++){
			printf("         "); 	
		} 
		for(j = max(0, i - r); j <= min(n - 1, i + s); j++){
			printf("%8.4f ", A1[i][j]);
		}
		printf("\n");
	}

	printf("\nMatrix L: \n");
	for(i = 0; i < n; i++){
		for(k = 0; k < max(0, i - r); k++){
			printf("         "); 	
		} 
		for(j = max(0, i - r); j <= i; j++){
			printf("%8.4f ", L[i][j]);
		}
		printf("\n");
	}	

	printf("\nMatrix U: \n");
	for(i = 0; i < n; i++){
		for(k = 0; k < i; k++){
			printf("         "); 	
		} 
		for(j = i; j <= min(n - 1, i + s); j++){
			printf("%8.4f ", U[i][j]);
		}
		printf("\n");
	}
	
	// Check if LU decomposition is correct
	if(flag) printf("The LU-decomposition program is correct.\n");
    else printf("The LU-decomposition program is incorrect.\n");	
}
