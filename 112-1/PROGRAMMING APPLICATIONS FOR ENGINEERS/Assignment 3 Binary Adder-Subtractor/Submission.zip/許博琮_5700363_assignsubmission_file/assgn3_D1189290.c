#include <stdio.h>
#include <math.h>
#include <string.h>
//Global variables for both input Xi,Yi, sum Si,Cout 
int X_arr[32] = {0};
int Y_arr[32] = {0};
int S_arr[32] = {0};
int C_out[32] = {0};


/*
Converting Sum Binary array to decimal for check the correctness of bianry adder-subtractor process.
argument : void	
*/

int BinaryToDecimal(){
	int sum = 0;
	int exp = 0;
	int LSB = S_arr[0];
	for(int i = 31;i>=0;i--){
		int bit = S_arr[i];
		
		//LSB is 1 means negative, than do the complement
		if(LSB == 1){
			bit = (bit==0?1:0);
			sum-= bit *pow(2,exp);
		}else{
			sum+= bit*pow(2,exp);	
		}
		
		exp++;
		
	}
	//LSB is 1 means negative, minus 1 for the sum.
	if(LSB == 1){
		sum -=1;
	}
	
	return sum;
}

/*
Function of the adder-subtractor process by inputing op char
argument
char op: '+' or '-'
*/ 
void Binary_AddSubtractor(char op){
	
	int M = (op=='+')?0:1;
	//Initialize the carry in3- bit to M.
	int c_in = M;
	for(int i = 31 ; i>=0 ; i--){
		int y_ = Y_arr[i] ^ M;
		int xi = X_arr[i];
		
		//Get Si
		int si = (xi ^ y_) ^ c_in;
		//Get Cout
		int c_out = (xi & y_) | (c_in & (xi^y_));
		
		S_arr[i] = si;
		C_out[i] = c_out;	
		//Let Cout be the next Carry in bit.
		c_in = c_out;
	}
	
	//Printf each four bits and seperate with one white space.
	for(int i=0; i<32; i++){
		printf("%d",S_arr[i]);
		if((i+1)%4==0){
			printf(" ");
		}
	}
	
	
}

/*
Function of Decimal to Binary array
argument: 
int dec : decimal number
int isXarray: flag for which input binary array to store, X_arr or Y_arr 
*/
void DecToBinary(int dec, int isXarry){
	int index = 31;
	int reminder = 0;
	int num = abs(dec);
	int temp_arr[32]={0};
	
	while(num>0){
		//Get reminder  
		reminder = num%2;
		//If negative, the do the complement
		if(dec<0){
			temp_arr[index] = (reminder==1?0:1);	
		}else{
			temp_arr[index] = reminder;
		}
		//Divide the number by two for next iteration.
		num /= 2;
		index--;
	}
	
	//If number is negative, to padding 1 for the rest bits which are not processed.
	if(dec<0){
		for(int i = 0; i<=index;i++){
			temp_arr[i] = 1;
		} 
	} 
	
	//Use carry in bit for positive or negative number
	int c_in = (dec<0 ?1:0);
	for(int i=31;i>=0;i--)
	{
		//Use a flag to choose which global binary array to store.
		if(isXarry){
			X_arr[i]=(temp_arr[i]+ c_in )%2;	
		}else{
			Y_arr[i]=(temp_arr[i]+ c_in )%2;
		}
		//Update the carry in bit for next iteration.
		c_in = (temp_arr[i]+ c_in)/2;
	}
	for(int i=0; i<32; i++){
		if(isXarry){
			printf("%d",X_arr[i]);
		}else{
			printf("%d",Y_arr[i]);
		}
		
		//Print a white space for each four bits.
		if((i+1)%4==0){
			printf(" ");
		}
	} 
	
}


int main(void){
	//Local decimal variables for X,Y,S, char op 
	int X,Y,S;
	char op = '\0';
	
	//do-while loop for this program until the input X==0 AND Y==0
	do{
		//Initialize the variables and global binary arrays.
		X = 0;
		Y = 0;
		S = 0;
		memset(X_arr,0,sizeof(X_arr));
		memset(Y_arr,0,sizeof(Y_arr));
		memset(S_arr,0,sizeof(S_arr));
		memset(C_out,0,sizeof(C_out));
		//Print the instruction and Scan user's input for X, Y, op
		printf("Enter \" X + Y \"  or \" X - Y \"(X, Y: -2,147,483,648 to 2,147,483,647):");
		scanf("%d %c %d", &X,&op,&Y);
		fflush(stdin);
		
		//Check if it needs to exit the loop.
		if(X==0 && Y==0){
			break;
		}
	
		//Print the decimal value of X and make it left alignment. the maximum length for 32 bits signed integer is 11.  
		printf("X = %-11d  Binary Value:",X);
		//Print the 32 bits binary array of X, each four bits with a white space.
		DecToBinary(X,1);
		printf("\n");
	
	
		//Print the decimal value of Y and make it left alignment. the maximum length for 32 bits signed integer is 11.  
		printf("Y = %-11d  Binary Value:",Y);
		//Print the 32 bits binary array of Y, each four bits with a white space.
		DecToBinary(Y,0);
		printf("\n");
	
	
		//Decimal calculation according to input op char. 
		if(op=='+'){
			S = X+Y;
		}else{
			S = X-Y;
		}
		//Print the decimal value of S and make it left alignment. the maximum length for 32 bits signed integer is 11.
		printf("S = %-11d  Binary Value:",S);
		//Call function of binary adder-subtractor process and print the sm binary array each four bits with a white space.
		Binary_AddSubtractor(op);
		printf("\n");
		
		//Converting Sum binary array to decimal to check the correctness for the above process.
		int verify = BinaryToDecimal();
		
		if(verify == S){
			printf("Correct! Adder-subtractor operation test: %d %c %d = %d",X,op,Y,S);
			printf("\n");
		}
		
		//Use the first and second bit of C out binary array to check if it is overflow.	
		int IsOverFlow = C_out[0] ^ C_out[1];
		if(IsOverFlow){
			printf("**** The addition-subtraction operation is overflow.\n");
		}
		//Print the seperator with 20 '-' to identify the end of a run.
		printf("%*s",20,"-");
		printf("\n");
	}while(1);
	
	return 0;
}
