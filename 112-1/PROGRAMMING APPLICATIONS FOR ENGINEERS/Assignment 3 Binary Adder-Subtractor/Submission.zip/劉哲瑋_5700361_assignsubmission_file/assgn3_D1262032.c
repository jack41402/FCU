#include <stdio.h>

int main(void)
{
    int X, Y, M, X1, Y1;
    /*
     M is used to indicate addition or subtraction operation.
     X1 is used to store the value of X the user entered.
     Y1 is used to store the value of Y the user entered.
    */
    char op; // Operator
    while (1) // Continue to process the adder-subtractor until both input are 0's.
    {
        printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648 to 2,147,483,647): ");
        scanf("%d %c %d", &X, &op, &Y);
        if (X==0 && Y==0) break;
        X1=X;
        Y1=Y;
        printf("X = %-11d  Binary value: ", X);
        for (int i=1; i<=32; i++)
            // Output the 32-bit binary representation of decimal number X.
        {
            printf("%d", (X>>(32-i))&1); // Output a bit of X from left to right.
            if(i%4==0) printf(" ");
        }
        printf("\n");
        printf("Y = %-11d  Binary value: ", Y);
        for (int i=1; i<=32; i++)
            // Output the 32-bit binary representation of decimal number Y.
        {
            printf("%d", (Y>>(32-i))&1); // Output a bit of Y from left to right.
            if(i%4==0) printf(" ");
        }
        printf("\n");
        if (op == '-') // subtraction operation
        {
            M = 1;
        }
        else // addition operation
        {
            M = 0;
        }
            int S = 0;
            int pos; // Position of the current bit.
            int x, y, s; // A single bit of X, Y, and S, respectively.
            int c = 0; // Initial carry in to 0.
            int cin = c, cout = M;
            for (pos=0; pos<32; pos++) // 32-bit adder.
            {
                x = X & 1;
                y = (Y & 1) ^ M;
                // Using xor M to take the 1's complement when M=1.
                cin = cout;
                s = (x ^ y) ^ cin;
                cout = (x & y) | (cin & (x ^ y));
                X = X >> 1;
                Y = Y >> 1;
                S = S | (s << pos);
                // Place the sum bit s in sum to the appropriate position of S specified by pos.
            }
        c = cin ^ cout; // To decide whether overflow occurs.
        printf("S = %-11d  Binary value: ", S);
        for (int i=1; i<=32; i++)
            // Output the 32-bit binary representation of decimal number S.
        {
            printf("%d", (S>>(32-i))&1); // Output a bit of S from left to right.
            if(i%4==0) printf(" ");
        }
        printf("\n");
        if (op == '-') // To confirm that the binary adder-subtractor has the same result as the subtraction operation of C programming language.
        {
            if (X1-Y1==S) printf("Correct! Adder-subtractor operation test: %d - %d = %d\n", X1, Y1, S);
            else printf("Incorrect! Adder-subtractor operation test: %d - %d != %d\n", X1, Y1, S);
        }
        else // To confirm that the binary adder-subtractor has the same result as the addition operation of C programming language.
        {
            if (X1+Y1==S) printf("Correct! Adder-subtractor operation test: %d + %d = %d\n", X1, Y1, S);
            else printf("Incorrect! Adder-subtractor operation test: %d + %d != %d\n", X1, Y1, S);
        }
        if (c!=0) printf("**** The addition-subtraction operation is overflow.\n");
        // Print the overflow message.
        printf("-----------------------------------------------------\n");
    }
    return 0;
}

