#include <stdio.h>
#include <limits.h>

// Function to print the binary representation of an integer
void printBinary(int value) {
    int i;
    for (i = 31; i >= 0; i--) {
        printf("%d", (value >> i) & 1);
        if (i % 4 == 0) {
            printf(" ");
        }
    }
    printf("\n");
}

int main() {
    int X, Y, S;
    char operation;

    do {
        // Prompting the user for input
        printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648 to 2,147,483,647): ");
        
        // Reading the user input for integers and operator
        int result = scanf("%d %c %d", &X, &operation, &Y);
        
        // Checking for end of file, if true, exit the loop
        if (result == EOF) {
            break;
        }

        // Printing the decimal value and binary representation of X
        printf("X = %d\t\tBinary value: ", X);
        printBinary(X);
        
        // Printing the decimal value and binary representation of Y
        printf("Y = %d\t\tBinary value: ", Y);
        printBinary(Y);

        // Performing addition or subtraction based on the operator
        if (operation == '+') {
            S = X + Y;
        } else if (operation == '-') {
            S = X - Y;
        } else {
            printf("Invalid operation!\n"); // Print an error message if the operator is not + or -
            continue; // Skip this iteration and move to the next
        }

        // Printing the decimal value and binary representation of S
        printf("S = %d\t\tBinary value: ", S);
        printBinary(S);

        // Printing the operation result
        printf("Correct! Adder-subtractor operation test: %d %c %d = %d\n", X, operation, Y, S);
        
        // Checking for overflow
        if ((X > 0 && Y > 0 && S < 0) || (X < 0 && Y < 0 && S > 0)) {
            printf("**** The addition-subtraction operation is overflow.\n");
        }
        
        // Printing a separator line
        printf("-----------------------------------------------------\n");
    } while (1); // Continue indefinitely until the user inputs EOF

    return 0;
}

