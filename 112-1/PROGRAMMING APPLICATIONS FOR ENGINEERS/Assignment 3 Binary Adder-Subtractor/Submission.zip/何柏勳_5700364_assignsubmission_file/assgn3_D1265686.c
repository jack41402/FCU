#include<stdio.h>

// Output the 32-bit binary representation of decimal number a.
void printbinary(int a)
{ 
	int i; // loop vairable
	for(i=1;i<=32;++i) // Output all 32 bits.
	{
		printf("%d",(a>>(32-i))&1); // Output a bit of n from left to right.
		if (i%4==0)  // Print a space every four bits.
		{
			printf(" ");
		}
	}
}

int main()
{

	int X,Y,M;
	char op;
	while(1) //Continue to process the adder-subtractor until both input are 0's.
	{
		printf("Enter \"x+y\" or \"x-y\"(x,y:-2,147,483,648 to 2,147,483,647):"); 
		scanf("%d %c %d",&X ,&op ,&Y);
		if (X==0&&Y==0) break; //If both X and Y are 0, stop the loop and terminate the program.
		printf("X = %-11d  Binary value: ", X); 
		printbinary(X);
		printf("\n");
		printf("Y = %-11d  Binary value: ", Y);
		printbinary(Y);
		printf("\n");
		
		// Confirm it is a substrator or adder
		if(op=='-')
		{
			M=1;
		}
		else
		{
			M=0;
		}
		
		int g;
		int x, y;
		int cin, cout ,S ,s;
		cin=0;  
		cout=M;
		S=0;
		
		
		for(g=0;g<32;++g)
		{
			x=(X>>g)&1;  
			y=((Y>>g)&1) ^ M;
			cin=cout;
			s=(x^y)^cin;
			cout=(x&y)|(cin&(x^y));
			S = S | (s<<g);
		}
		cin = cin ^ cout;
		
		printf("S = %-11d  Binary value: ",S);
		printbinary(S);
		printf("\n");
		
		
		// Confirm whether the program is correct or wrong
		if(M==0)
		{
			if(X+Y==S)
			{
				printf("Correct! Adder-subtractor operation test: %d + %d = %d\n",X ,Y ,S);
			}
			else
			{
				printf("Incorrect! Adder operation test: %d + %d != %d\n", X, Y, S);
			} 		
			
		}
		else
		{
			if(X-Y==S)
			{
				printf("Correct! Adder-subtractor operation test: %d - %d = %d\n",X ,Y ,S);
			}
			else
			{
				printf("Incorrect! Adder-subtractor operation test: %d - %d != %d\n", X, Y, S);
			}
		}
		
		if (cin!=0){
			printf("**** The addition operation is overflow.\n");
		}
		
		printf("-----------------------------------------------------\n");
    }
}
