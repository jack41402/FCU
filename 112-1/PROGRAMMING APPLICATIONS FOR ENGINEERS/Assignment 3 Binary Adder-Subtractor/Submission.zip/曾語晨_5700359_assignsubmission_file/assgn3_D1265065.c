#include<stdio.h>
#include<stdlib.h>
//create a new function called printBinary to change decimal number into binary number
void printBinary(int n){
	int i;//loop variable
	for(i=1;i<=32;i++){// to output 32 bits
		printf("%d", (n>>(32-i))&0X00000001); //print binary number
	    if (i%4==0) printf(" ");// every four bits print a blank
	} 
}
//create a new function called fullAdder to calculate numbers and follow the logic formula of full adder
void fullAdder (int x, int y, int *c, int *s) {
  *s = (x ^ y) ^ *c; // s = (x xor y) xor c_in
  *c = (x & y) | (*c & (x ^ y)); // c_out = (x and y) or (c_in and (x xor y)) 
}
//create a new function to calculate numbers
int adder(int X, int Y, int *c) {
  int S = 0;//variable S represents sum
  int pos;//variable pos represents position
  int x, y, s; //variables express bit from X, Y, S
  int cin = *c, cout = 0;//variables to calculate the carries
  for (pos=0; pos<32; pos++) {//create a loop to compute numbers
    x = X & 1; //set x to current bit of X
    y = Y & 1; //set y to current bit of y
    cin = cout;//set the current carry to the previous carry
    fullAdder(x, y, &cout, &s);//call fullAdder function
    X = X >> 1; //to shift its bit one po sition to the right-hand-side
    Y = Y >> 1; //to shift its bit one po sition to the right-hand-side
    S = S | (s << pos);//place the sum bits to the appropriate position
  }
  *c = cin ^ cout;//set c to cin xor cout
  return S;//return the results
}

int main(void){
	int X, Y, S;//create variables for calculation
	int c;//create variable for carry
	char op;//create variable for "+" or "-"
	while(1){//make the loop keep running
	printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648 to 2,147,483,647): ");//print out the text for asking enter numbers
	scanf("%d %c %d", &X, &op, &Y);//scan what numbers are input
	if(X==0 && Y==0) break;//if X equals 0 and Y equals 0, loop will stop running
	c = 0;//set initial carry to 0
	
	printf("X = %-10d  Binary value: ", X);//print out the decimal value of X
	printBinary(X);// print out the binary value of X by calling the function printBinary
	printf("\n");//print out newline
	printf("Y = %-10d  Binary value: ", Y);//print out the decimal value of Y
	printBinary(Y);// print out the binary value of Y by calling the function printBinary
	printf("\n");//print out newline
	
	if(op=='+')	{//if the operation is +
		S = adder(X, Y, &c);//calculate sum (X+Y) by calling adder function
	}
	else if(op=='-'){//if the operation is -
		Y = ~Y+1;//Y becomes -Y in order to calculate subtraction by using x + (-Y)
		S = adder(X, Y, &c);//calculate sum (X-Y) by calling adder function
	}
	
	printf("S = %-10d  Binary value: ", S);//print out the decimal value of S
	printBinary(S);// print out the binary value of S by calling the function printBinary
	printf("\n");//print out newline
	if(X+Y==S) {//to verify if calculation is correct or not
		printf("Correct! Adder-subtractor operation test: %d %c ", X, op);//print out the text
		if(op=='-') printf("%d",~Y+1);//Bcause of previous code, we make Y into -Y. Now we have to turn it back to original value in op=='-' situation
		else printf("%d",Y);//print out Y value in op=='+' situation
		printf("= %d\n", S);//print out the remaining part of text
	}
	else {//if X+Y!=0 then print out text of incorrect situation
	printf("Incorrect! Adder-subtractor operation test: %d %c %d != %d\n", X, op, Y, S);
	}
	
	if(c!=0) printf("**** The addition-subtraction operation is overflow.\n");//verify if cin xor cout equals 0 or not. if c doesn't equal 0, print overflow text. 
	printf("-----------------------------------------------------\n");//print out separated line
}
	return 0;
}
