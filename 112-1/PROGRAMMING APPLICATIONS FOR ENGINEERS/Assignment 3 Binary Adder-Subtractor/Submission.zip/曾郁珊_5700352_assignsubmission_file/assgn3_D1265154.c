#include <stdlib.h>
#include <stdio.h>

int main(void){
	int X,Y,i,c,S,x,y,s,a,b;// Declare integer variables X, Y, i, c, and S.
	char op;// Declare a character variable op.
	
	while(1){// Start an infinite loop using a while statement.
		// Prompt the user to enter an expression in the format "X + Y" or "X - Y".
		printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,647 to 2,147,483,647): ");
		scanf("%d %c %d",&X,&op,&Y);
		c = 0; // Initial carry in to 0.
		a = X;
		b = Y;
		
		// Read the values of X, op (operator), and Y from user input.
		if (X==0 && Y==0) break;// Check if both X and Y are zero. If so, exit the loop.
		printf("X = %d",X);// Print the value of X.
		printf("\t\t Binary value: ");
		// Print a message indicating the binary value will be displayed.
	//X
		for (i = 31; i >= 0; --i) {
    	// Iterate through each bit of X starting from the most significant bit (bit 31).
    		if (((1 << i) & X) == 0) {
        	// Check if the i bit of X is 0 by using a bitwise AND operation with a mask.
        	printf("0");  // Print '0' to represent a binary zero.
    		} else {
        		printf("1");  // Print '1' to represent a binary one.
    		}
    		if (i % 4 == 0) {
        	// Insert a space every 4 bits for better readability.
        		printf(" ");
    		}
		}
	//Y
		printf("\n"); 
		// Print a newline to separate the binary representations of X and Y.
		printf("Y = %d", Y);  // Print the value of Y.
		printf("\t\t Binary value: ");  // Indicate that the binary value will be displayed for Y.

		for (i = 31; i >= 0; --i) {
    	// Iterate through each bit of Y, similar to the previous loop for X.
    		if (((1 << i) & Y) == 0) {
        		printf("0");
    		} else {
        		printf("1");
    		}
    		if (i % 4 == 0) {
        		printf(" ");
    		}
		}
	//to calculate the two's complement of a binary number	
		if(op == '-'){
        	
        	Y = ~Y+1;	
        }
        
		S = 0;// Initialize the result S to 0.
		for(i=0;i<32;++i){
			x = X & 1;// Extract the least significant bit of X.
			y = Y & 1;// Extract the least significant bit of Y. 
			s = (x ^ y) ^ c; // s = (x xor y) xor c_in.
    		c = (x & y) | (c & (x ^ y)); // c_out = (x and y) or (c_in and (x xor y))
    		X =X>>1;// Right-shift X to process the next bit position.
    		Y =Y>>1;// Right-shift Y to process the next bit position.
    		S = S | (s << i);// Update the result S by setting the current bit (s) at position i.
		}
		
    	printf("\n");// Print a newline character for formatting.
		printf("S = %d",S);// Print the decimal value of S.
    	printf("\t\t Binary value: ");// Print the binary value of S.
    	
      	for ( i = 31; i >= 0; i--) {
      	// Right-shift S by i positions and use a bitwise AND to extract the current bit (0 or 1).
            	printf("%d", (S >> i) & 1);
        	if (i % 4 == 0) {// Check if the current bit position is a multiple of 4 (for adding a space).
        		printf(" ");
    		}
        }
    	printf("\n");// Print a newline character for formatting.
        
		if (op == '-'){// If the operator is a minus sign ('-'), then:
            if (a-b==S) printf("Correct! Adder-subtractor operation test: %d - %d = %d\n", a, b, S);
            else printf("Incorrect! Adder-subtractor operation test: %d - %d != %d\n", a, b, S);
            // Check if the result of subtracting 'a' from 'b' is equal to 'S'. 
    		// If it is, print a correct message; otherwise, print an incorrect message.
		}
		
		else{// If the operator is not a minus sign, then:
            if (a+b==S) printf("Correct! Adder-subtractor operation test: %d + %d = %d\n", a, b, S);
            else printf("Incorrect! Adder-subtractor operation test: %d + %d != %d\n", a, b, S);
            // Check if the result of adding 'a' to 'b' is equal to 'S'. 
    		// If it is, print a correct message; otherwise, print an incorrect message.
    	}
    	
         if ((a > 0 && b > 0 && S < 0) || (a < 0 && b < 0 && S > 0)) {
		//If either (a is positive and b is positive and S is negative) or (a is negative and b is negative and S is positive), then:
 		
	        printf("**** The addition operation has overflow.\n");// Print a message indicating an overflow.
	        printf("-----------------------------------------------------\n");
		}	    
    }		
}
 	



 
	   
		
		
	
		

