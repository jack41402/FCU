#include <stdio.h>
#include <stdlib.h>

void printbinary(int n) {
    int i;
    for (i = 0; i < 32; i++) {
        printf("%d", (n >> (31 - i)) & 1);
        if (i % 4 == 3) printf(" ");
    }
}

void fullAdder(int x, int y, int *c, int *s) {
   *s = (x ^ y) ^ *c; 
   *c = (x & y) | (*c & (x ^ y));
}

unsigned int adder_subtractor(int X, int Y, int M, int *c_in, int *overflow) {
    unsigned int S = 0;
    int c_out;
    int pos;
    int x,y,s,c;
    c=M;
    *c_in=0;
    for (pos = 0; pos < 32; pos++) {
        x = (X >> pos) & 1;
        y = ((Y >> pos) & 1) ^ M; 
        c_out = *c_in;
        fullAdder(x, y, &c, &s);
        S |= (s << pos);
        *c_in = c_out ;
    }
     *overflow = c ^ c_out^*c_in;
    return S;
}

int main() {
    int X, Y, S, M;
    int overflow, c_in;
    char op;
    
    do {
        printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648 to 2,147,483,647): ");
        scanf("%d %c %d", &X, &op, &Y);
        if (op=='+')
			 M=0;
        else if (op=='-') 
			M=1;
        S = adder_subtractor(X, Y, M, &c_in, &overflow);
        printf("X = %d   ", X);
        printbinary(X);
        printf("\n");
        printf("Y = %d   ", Y);
        printbinary(Y);
        printf("\n");
        printf("S = %d   ", S);
        printbinary(S);
        printf("\n");
        if(M==0){
			if(X+Y==S)
        	printf("Correct! Add-subtractor operation test: %d + %d = %d\n",X,Y,S);
        	else
        	printf("Incorrect! Add-subtractor operation test: %d + %d != %d\n",X,Y,S);
	}
		else if(M==1){
        	if(X-Y==S)
        	printf("Correct! Add-subtractor operation test: %d - %d = %d\n",X,Y,S);
        	else 
        	printf("Incorrect! Add-subtractor operation test: %d - %d != %d\n",X,Y,S);
}
		if(overflow==1) printf("****The addition-subtraction operation is overflow.\n");
		printf("---------------------------------------------------------------------\n");
	}while(X!=0&&Y!=0);
    return 0;
}

