//
//  main.c
//  assgn3
//
//  Created by pierre huang on 2023/10/21.
//

#include <stdio.h>
int* binary_number(int a){
    static int binary_value[32];
    int i;
    int j=1;
    for(i=0;i<32;i++){
        binary_value[i]=0;
    }
    for(i=31;i>=0;i--){
        if((a&j)==j){
            binary_value[i]=1;
        }else{
            binary_value[i]=0;
        }
        j = j << 1;
    }
    return binary_value;
}
void print_value(int a){
    int i;
    printf("Binary value: ");
    for(i=0;i<32;i++){
        if(i%4==0){
            printf("% d",binary_number(a)[i]);
        }
        else{
            printf("%d",binary_number(a)[i]);
            }
    }printf("\n");
}
void binary_adder_subtractor(int a, int b, int m, int v){
    int i;
    int c_in=0,c_out=0;
    int binary_adder_value[32];
    for(i=0;i<32;i++){
        binary_adder_value[i]=0;
    }
    if(m==1)b=-b;
    for(i=31;i>=0;i--){
        binary_number(a)[i]=(binary_number(a)[i])&1;
        binary_number(b)[i]=(binary_number(b)[i])^m;
        c_in=c_out;
        binary_adder_value[i]=(binary_number(a)[i]^binary_number(b)[i])^c_in;
        c_out=(binary_number(a)[i]&binary_number(b)[i])|(c_in&(binary_number(a)[i]^binary_number(b)[i]));
    }
    v=c_in^c_out;
    printf("Binary value: ");
    for(i=0;i<32;i++){
        if(i%4==0){
            printf("% d",binary_adder_value[i]);
        }
        else{
            printf("%d",binary_adder_value[i]);
            }
    }printf("\n");
    if(v==1){
        if(m==0){
            printf("Correct! Adder-subtractor operation test: %d + %d = %d\n", a, b, a+b);
            printf("**** The addition-subtraction operation is overflow.\n");
        }else{
            printf("Correct! Adder-subtractor operation test: %d - %d = %d\n", a, b, a-b);
            printf("**** The addition-subtraction operation is overflow.\n");
        }
    }
    else{
        if(m==0){
            printf("Correct! Adder-subtractor operation test: %d + %d = %d\n", a, b, a+b);
        }else{
            b=-b;
            printf("Correct! Adder-subtractor operation test: %d - %d = %d\n", a, b, a-b);
        }
    }
}
int main(){
    int x,y,m,v=0;
    char op;
    do{
        printf("Enter \"X + Y\" or \"X - Y\" ( X. Y: -2,147,483,648 to 2,147,483,648): ");
        scanf("%d %c %d", &x, &op, &y);
        printf("\n");
        if(x==0&&y==0)break;
        if(op=='+'){
            m=0;
            printf("X = %-10d   ",x);
            print_value(x);
            printf("Y = %-10d   ",y);
            print_value(y);
            printf("S = %-10d   ",x+y);
            binary_adder_subtractor(x,y,m,v);
        }else{
            m=1;
            printf("X = %-10d   ",x);
            print_value(x);
            printf("Y = %-10d   ",y);
            print_value(y);
            printf("S = %-10d   ",x-y);
            binary_adder_subtractor(x,y,m,v);
        }printf("-----------------------------------------------------\n");
    }while(x!=0&&y!=0);
}
