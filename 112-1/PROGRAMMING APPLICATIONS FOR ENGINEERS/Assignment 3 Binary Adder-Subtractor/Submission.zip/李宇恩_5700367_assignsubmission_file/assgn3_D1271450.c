#include<stdio.h>
void fullAdder (int x, int y, int *c, int *s) {
  *s=(x ^ y) ^ *c; //s = (x xor y) xor c_in
  *c = (x & y) | (*c & (x ^ y));}//c_out = (x and y) or (c_in and (x xor y))
int adder(int X, int Y, int*c, int M){
	int pos,x, y, s, S, i, cin, cout;//declaring variables
	S = 0;//setting zero as S's initial value
	*c = M;//setting M as *c's initial value
	cin = *c;//setting *c as cin's initial value
	cout = M;//setting M as cout's initial value
for(pos=0; pos<32;++pos){//32-bit adder
	x=X & 1;//set x to the current bit of X, i.e., the least significant bit of X
	y=(Y&1)^M;//set y to the current bit of Y, i.e., the least significant bit of Y xor M
	cin=cout;//setting the cout equals the next cin
	fullAdder(x, y, &cout, &s); //the shift operation is to move the next processed bit of X and Y to the least significant bit
	X=X>>1;//update X to shift its bits one position to the right-hand-side
	Y=Y>>1;//update Y to shift its bits one position to the right-hand-side
	S=S | (s<<pos);}//place the sum bit s in sum to the appropriate position of S specified by pos
	*c=cin^cout;//setting *c as cin xor cout
	return S;//return the result sum
	
}
void printBinary(unsigned int n){//output the 32-bit binary representation of decimal number n
	int i;//loop vairable
	for(i=1;i<=32;++i){//output all 32 bits
		printf("%d", (n>>(32-i))&1);//print a bit of n from left to right
		if(i%4==0){//print a space every four bits
			printf(" ");//print space
		}
	}
}

int main(void){
	int X, Y, S, i, n, T, M, c, v;//declaring the variables
	char op;//declaring the +,- sign's variables
	if(op=='+' || '-'){//if it is an addition or subtraction operation do the executions below
	do{//do the executions below 
	printf("Enter\"X+Y\" or \"X-Y\"(X, Y: -2,147,483,648 to 2,147,483,647): ");//print Enter\"X+Y\" or \"X-Y\"(X, Y: -2,147,483,648 to 2,147,483,647)
	scanf("%d %c %d",&X, &op,&Y);//scan the numbers and symbols entered
	
	if(op=='+'){//if it is an addition operation, M will be set as zero
		M=0;//M will be set as zero
	}
	else{//if it is an subtraction operation, M will be set as one
		M=1;//M will be set as one
	}
	if(X==0&&Y==0) break;//if X and Y both equals zero, print nothing
	c=M;//set the initial carry-in as M
	S=adder(X, Y, &c, M);//calling adder from above
	
	
	printf("X=%d\t\tBinary value: ",X);//output decimal value of X with left alignment
	printBinary(X);//output binary value of X
	printf("\n");//change to next line
	printf("Y=%d\t\tBinary value: ",Y);//output decimal value of Y with left alignment
	printBinary(Y);//output binary value of Y
	printf("\n");//change to next line
	printf("S=%d\t\tBinary value: ",S);//output decimal value of the sum S with left alignment
	printBinary(S);//output binary value of S
	printf("\n");//change to next line
	if(op=='+'){//if it is an addition operation
		if(X+Y==S){//if it is an addition operation and X plus Y equals S
		printf("Correct! Adder-subtractor operation test: %d + %d = %d", X,Y,S);}//print Correct! Adder-subtractor operation test: X + Y = S
	else{//if it is an addition operation but X plus Y doesn't equal zero
		printf("Incorrect! Adder-subtractor operation test: %d + %d = %d", X,Y,S);//print Incorrect! Adder-subtractor operation test: X + Y = S
	}}
	else{//if it is an subtraction operation
		if(X-Y==S){//if it is an subtraction operation and X - Y equals S
			printf("Correct! Adder-subtractor operation test: %d - %d = %d", X,Y,S);}//print Correct! Adder-subtractor operation test: X - Y = S
	else{//if it is an subtraction operation but X - Y doesn't equal S
		printf("Incorrect! Adder-subtractor operation test: %d - %d = %d", X,Y,S);//print Incorrect! Adder-subtractor operation test: X - Y = S
		}
	}
	if(c!=0){//if c doesn't equal zero
	printf("\n");//change to next line
		printf("**** The addition-subtraction operation is overflow.");// print **** The addition-subtraction operation is overflow.
	}
		
printf("\n");//change to next line
	for(i=0;i<52;++i){//print seperate line
		printf("_");}//print _
		printf("\n");//change to next line
	}
	while(1);
}
	else{//if the operation is neither addition nor subtraction, print error
		printf("Error");//print error
	}
	while(X!=0||Y!=0);//do the execution above while X or Y doesn't equal zero
	return 0;
}
