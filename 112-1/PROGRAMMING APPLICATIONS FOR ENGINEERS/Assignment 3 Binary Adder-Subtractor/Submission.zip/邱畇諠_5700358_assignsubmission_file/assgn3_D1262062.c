# include <stdio.h>
# include <stdlib.h>

void printBinary(unsigned int n)
{
	int i;
	for (i=1; i<=32; i++)// Repeat until output all 32 bits of decimal number n.
	{
  		printf("%d", (n>>(32-i))&0X00000001);// Ouput a bit from left to right.
		if (i%4==0) printf(" "); 
  	}
}
void fullAdder (int x, int y, int *c, int *s)// The fullAdder function.
{
  *s = (x ^ y) ^ *c;// s = (x xor y) xor c in.
  *c = (x & y) | (*c & (x ^ y));// c out = (x and y) or (c in and (x xor y)).
}
unsigned int adder(unsigned int X, unsigned int Y,int M, int *c)// The adder funtion.
{
	unsigned int S = 0;// Initial the sum to 0 and the value of the final result will return.
	int pos;// Position. 
	int x, y, s;
	int cin, cout=M;
	for (pos=0; pos<32; pos++)// Repeat until 32-bit adder is finished.
	{
		x = X & 1;// Set x to the current bit of X.
		y = (Y & 1)^M;// Set y to the current bit of Y and Xor the value of M.
		cin = cout;
		fullAdder(x, y, &cout, &s);// Call the fullAdder function.
		X = X >> 1;// Shift X's bits one position to the right-hand-side.
		Y = Y >> 1;//Shift Y's bits one position to the right-hand-side.
		S = S | (s << pos);// Place the sum bit s in sum to the appropriate position of S specified by pos.
	}
	*c = cin^cout;// The value of final c out = the xor of the last two bits.
	return S;
}
int main(void)
{
	unsigned int X, Y, S, M;
	int c;
	char op;
	while(1){// Continue until the input are both 0.
	printf("Enter ""X+Y"" or ""X-Y"" (X. Y: -2.147.483.648 to 2.147.483.647): ");// Input two integers and the operator between them.
	scanf("%d %c %d", &X, &op, &Y);
	if (X==0 && Y==0) printf("�L�n�`�� �b:"); break;// Stop the loop when both X and Y are 0.
	printf("X = %-10d  Binary value: ", X);// Print out decimal value of X.
    printBinary(X);// Print out binary value of X.
    printf("\n");// Move to a new line.
    printf("Y = %-10d  Binary value: ", Y);// Print out decimal value of Y.
    printBinary(Y);// Print out binary value of Y.
    printf("\n");// Move to a new line.
	if (op=='+') M=0;// If the operator is '+' M is set to 0.
	else if(op == '-') M=1;// If the operator is '-' M is set to 1.
	c = 0;// Initial carry in to 0.
	S = adder(X, Y, M, &c);// Call the adder function and get the value of the sum.
    printf("S = %-10d  Binary value: ", S);// Print out decimal value of S.
    printBinary(S);// Print out binary value of S.
    printf("\n");// Move to a new line.
	if(op == '-')// If the operator is '-'.
	{
		if (X-Y==S) printf("Correct! Adder-subtractor operation test: %d - %d = %d\n", X, Y, S);// Do the subtraction to check whether the value is correct or not and output the result.
	    else printf("Incorrect! Adder-subtractor operation test: %d - %d != %d\n", X, Y, S);
	}
	else// If the operator is '+'.
	{
		if (X+Y==S) printf("Correct! Adder operation-subtractor test: %d + %d = %d\n", X, Y, S);// Do the addition to check whether the value is correct or not and output the result.
	    else printf("Incorrect! Adder-subtractor operation test: %d + %d != %d\n", X, Y, S);
	}
	if(c!=0) printf("**** The addition-subtraction operation is overflow.\n");// If the value of the xor of the last two bits is not equal to 0 the operation is over flow, print out the overflow message.
    printf("-----------------------------------------------------\n");
  	}
  	return 0;
}
