#include <stdio.h>

void printbinary(int x)//Function to print the binary representation of an integer
{ 
	int i;//declare variables
	for(i=1;i<=32;++i)//print all 32 bits
	{
		printf("%d",(x>>(32-i))&1);//output the x from left to right 
		if (i%4==0)//print the space to separate every four numbers 
		{
			printf(" ");
		}
	}
	printf("\n");
}

int main()
{
	int X,Y;//declare two variables for calculate
	char op;//declare operator
	int M;//declare the variables used to indicate addition or subtraction operation by 0 and 1
	int c_in;//represents the carry-in bit
	while(1)
	{
		printf("Enter \"X+Y\" or \"X-Y\" (X,Y:-2,147,483,648 to 2,147,483,648):");
		scanf("%d %c %d",&X,&op,&Y);//scan the X, op, and Y
		if (X==0&&Y==0) break;//if both are 0, then stop the loop
		printf("X=%d			",X);//print out interger of X
		printf("Binary value:");
		printbinary(X);//print out binary value
		printf("Y=%d			",Y);//print out interge of Y
		printf("Binary value:");
		printbinary(Y);//print out binary value
		if(op=='+')
		{
			M=0;//Select addition operation
		}
		else if(op=='-')
		{
			M=1;//Select addition operation
		}
		int S=0;//represents the result of the operation
	   	int i;
	   	int xi,yi,c_out,s;
	   	//xi and yi represent individual bits of X and Y; c_out is carry-out; s is the sum; c represents overflow
	   	c_out=M;
	    for (i=0;i<32;i++) 
		{
	        xi=(X>>i)&1;//right-shifting X by i positions and then using bitwise AND with 1 to isolate the least significant bit at position i.
	        yi=((Y>>i))&1^M;//right-shifting Y by i positions and then using bitwise AND with 1 to isolate the least significant bit at position i. Using xor M to take the 1's complement when M=1.
	        c_in=c_out;// Store the value of c_out into c_in.
	        s=(xi^yi)^c_in;// s = (x xor y) xor c_in
			c_out=(xi&yi)|(c_in&(xi^yi));// c_out = (x and y) or (c_in and (x xor y))
			S=S|(s<<i);//Place the sum bit s in sum to the appropriate position of S specified by i.
		}
		printf("S=%d			",S);//print out integer of sum
		printf("Binary value:");
		printbinary(S);//print out binary value
		// Print the confirming message. The else case should not be executed.
		if(M==0)
		{
			if(X+Y==S)
			{
				printf("Correct! Adder-subtractor operation test: %d + %d = %d\n",X ,Y ,S);
			}
			else
			{
				printf("Incorrect! Adder operation test: %d + %d != %d\n", X, Y, S);
			} 			
		}
		else
		{
			if(X-Y==S)
			{
				printf("Correct! Adder-subtractor operation test: %d - %d = %d\n",X ,Y ,S);
			}
			else
			{
				printf("Incorrect! Adder-subtractor operation test: %d - %d != %d\n", X, Y, S);
			}
		}
		// Print the overflow message.
		int c=c_in^c_out;// To decide whether overflow occurs.
		if(c!=0){
			printf("**** The addition operation is overflow.\n");
		}
		printf("-----------------------------------------------------\n");
    }
}
