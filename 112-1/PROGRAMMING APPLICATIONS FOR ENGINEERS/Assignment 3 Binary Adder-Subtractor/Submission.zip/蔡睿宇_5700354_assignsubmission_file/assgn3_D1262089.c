#include <stdio.h>

// Function to perform a full adder operation on bits x, y, and carry-in (cin)
// Returns the sum and sets cout (carry-out) by reference
int fullAdder(int x, int y, int cin, int *cout) {
    int sum = (x ^ y) ^ cin;  // Sum bit calculation
    *cout = (x & y) | (cin & (x ^ y));  // Carry-out calculation
    return sum;
}

// Function to print the binary representation of a number
void printBinary(int num) {
    for (int i = 31; i >= 0; i--) {
        printf("%d", (num >> i) & 1);
        if (i % 4 == 0) {
            printf(" ");  // Add a space every 4 bits for readability
        }
    }
}

int main() {
    int X, Y;
    char op;
    int S, M, c_in, c_out;
    int i;

    do {
        printf("Enter 'X + Y' or 'X - Y' (X, Y: -2,147,483,648 to 2,147,483,647): ");
        scanf("%d %c %d", &X, &op, &Y);

        if (X == 0 && Y == 0) {
            break;  // Exit the loop if both X and Y are 0
        }

        if (op == '+') {
            M = 0;  // Set M to 0 for addition
        } else if (op == '-') {
            M = 1;  // Set M to 1 for subtraction
        } else {
            printf("Invalid operator. Please use '+' or '-'.\n");
            continue;  // Prompt user to enter a valid operator
        }

        c_in = M;  // Initialize carry-in to the value of M
        S = 0;     // Initialize the result to 0
        c_out = 0; // Initialize carry-out to 0

        for (i = 0; i < 32; i++) {
            int xi = (X >> i) & 1;         // Get the i-th bit of X
            int yi = (Y >> i) & 1;         // Get the i-th bit of Y
            int y_prime = yi ^ M;          // Calculate y' based on M
            int sum = fullAdder(xi, y_prime, c_in, &c_out);  // Perform full adder operation
            S |= (sum << i);               // Update the result S
            c_in = c_out;                 // Update carry-in for the next iteration
        }

        // Check for overflow
        int overflow = 0;
        if ((X > 0 && Y > 0 && M == 0 && S < 0) ||
            (X < 0 && Y < 0 && M == 0 && S > 0) ||
            (X > 0 && Y < 0 && M == 1 && S < 0) ||
            (X < 0 && Y > 0 && M == 1 && S > 0)) {
            overflow = 1;  // Set overflow flag if overflow occurs
        }

        // Print the values and results
        printf("X= %-15d   Binary value:  ", X);
        printBinary(X);
        printf("\n");
        printf("Y= %-15d   Binary value:  ", Y);
        printBinary(Y);
        printf("\n");
        printf("S= %-15d   Binary value:  ", S);
        printBinary(S);
        printf("\n");

        printf("Correct! Adder-subtractor operation test: %d %c %d = %d\n", X, op, Y, S);

        if (overflow) {
            printf("**** The addition-subtraction operation has overflowed.\n");
        }
        printf("---------------------------------------------------------------------------\n");
    } while (X != 0 || Y != 0);

    return 0;
}
