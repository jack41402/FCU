#include <stdlib.h>
#include <stdio.h>

//Print Binary representation
void printBinary(int n)//void as doesn't return any value when printBinary was called
{
	int i;//Declare i in the use of for loop
	
	for(i = 31; i >= 0; i--)
	{
    	printf("%d", (n >> i) & 0X00000001);
	    if (i%4==0)//For every four bits
		{
			printf(" ");//Print space
		} 
	}
}
//Full adder
void fullAdder(int x, int y, int *c, int *s)
//Performed a full adder which infut x, y and *c, calculate the function and output *s
{
	*s = (x ^ y) ^ *c;//Sum output, the XOR function return different bits for equal bits
	*c = (x & y) | (*c & (x ^ y));//Carry output, using and function and or function on x, y and *c 
}
//Full subtractor
int adder(int X, int Y, int *c, int M)
//This function essentially acts as a 32-bit adder or subtractor, which allowed for both addition and subtraction operations with proper carry and borrow.
{
	int S = 0;//Declare S as 0 (back to zero)
	int position;//Declares integer variable named position from right to left
  	int x, y, s; //Declare x, y, s
  	int cin, cout;//Declare cin and cout in using overflow detection
  	cin = *c;//Set cin as carry output for overflow checking
  	cout = M;//Set cout as M for overflow checking
  
	for (position = 0; position < 32; position ++)//The loop iterates 32 times, 32-bit adder
	{ 
	x = X & 1;//Extract the least signficant bit of X
    y = (Y & 1) ^ M;//Extract the least significant bit of Y and perform XOR with M for calculqtion overflow
    
    cin = cout;//Updates the carry-in with the previous carry-out value
    fullAdder(x, y, &cout, &s);//Calls the fullAdder function, in the bits x and y, to cout and s. This function calculates the sum bit and updates the carry-out
    
    X = X >> 1;//Move X to 1-bit at right 
    Y = Y >> 1; //Move Y to 1 bit at left
  
    S = S | (s << position);//A bitwise operation that updates the variable 'S'
  	}
  	
  	*c = cin ^ cout;//The carry is set as while carry-in 
  	
	return S;//Return the final result of adder or subtractor
}

int main(void)//Function where the execution of the program begins 
{
	char operation;//Declare the operation
	
		int X, Y, S;//Compute S = X + Y or S = X - Y 
		int c;//Declare carry bit
		int M;//Declare M which is a variable used to represent the borrow or carry-in bit in binary addition and subtraction operations.
	
		while (1)//Create an infinite loop until a break statement is encountered. 
		{
	    printf("Enter \"X+Y\" or \"X-Y\" (X, Y: -2,147,483,648 to 2,147,483,647): ");//Enter the integer
	    scanf("%d %c %d", &X, &operation, &Y);//Scan the integer, operation and integer
	    
	    if(operation == '+')//Determine the Adder by checking out the operation
	    {
	    	M = 0;
			//When operation is '+', indicating addition, M is set to 0. In binary addition, there is no initial carry-in, so M (the carry-in) is set to 0
		}
		else if(operation == '-')//Determine the Subtractor by checking out the operation
		{
			M = 1;
			//When operation is '-', indicating subtraction, M is set to 1. In binary subtraction, the operation is effectively transformed into an addition with a borrow.
		}
	    
	    if (X==0 && Y==0)
	    { 
			printf("�L�n�`�� �b"); 
			break;//If both X and Y are 0, stop the loop and terminate the program. 
		}
	    
	    c = M;//Initial carry in to M, which it is easier to calculate the overflow
	    S = adder(X, Y, &c, M);//Call function adder
	
	    printf("X = %-10d  Binary value: ", X);//Print the label and the left-justified, 10-character wide unsigned integer value of X.
	    printBinary(X);//Call the function to print the binary representation of the integer X
	    printf("\n");//Escape sequence that represents a newline character
	    printf("Y = %-10d  Binary value: ", Y);// Print the label and the left-justified, 10-character wide unsigned integer value of Y.
	    printBinary(Y);//Call the function to print the binary representation of the integer Y
	    printf("\n");//Escape sequence that represents a newline character
	    printf("S = %-10d  Binary value: ", S);// Print the label and the left-justified, 10-character wide unsigned integer value of S.
	    printBinary(S);//Call the function to print the binary representation of the integer S
	    printf("\n");//Escape sequence that represents a newline character
	    
	    //Check operation and print result
		if(operation == '+')//Determine the Adder by checking out the operation
		{
			if (X + Y == S)//While the sum of X and Y is correct
			{
				printf("Correct! Adder operation test: %d + %d = %d\n", X, Y, S);//Output correct
			} 
		    else//while the sum of X and Y doesn't equal to the sum
			{
				printf("Incorrect! Adder operation test: %d + %d != %d\n", X, Y, S);//Output incorrect
			}
		}
		else if(operation == '-')//Determine the Subtractor by checking out the operation
		{
			if (X - Y == S)//While the difference of X and Y is correct
			{
				printf("Correct! Adder operation test: %d - %d = %d\n", X, Y, S);//Output correct
			} 
		    else//while the difference of X and Y doesn't equal to the difference
			{
				printf("Incorrect! Adder operation test: %d - %d != %d\n", X, Y, S);//Output incorrect
			} 
		}
	    if (c != 0) 
		//Check the value of carry, if c is not 0, it means there was an overflow during the addition operation
		{
			printf("**** The addition operation is overflow.\n");//Indicate that an overflow occurred
		}
	
	    printf("-----------------------------------------------------\n");//Print as the segment line 
		}
  return 0;//To indicate the successful execution of a program
}
