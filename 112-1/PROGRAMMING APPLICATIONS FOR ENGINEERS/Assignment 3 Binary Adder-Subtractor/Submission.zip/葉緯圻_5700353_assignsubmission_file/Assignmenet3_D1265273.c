#include <stdlib.h>
#include <stdio.h>

// Output the 32-bit binary representation with number n.
void printBinary(int n) {
  int i; //for loop vairable
  
  for (i=1; i<=32; i++) { // Output all 32 bits.
    printf("%d", (n>>(32-i))&0X00000001); // Output a bit of n from left to right.
    if (i%4==0) printf(" "); // Print a space every four bits.
  }
}

/*
	x and y represent the two input bits. s and c represent 
  the sum bit and the carry bit, respectively. The initial value of c is 
  the carry_in and cout represent the carry_out. Parameters s and c 
  are declared as call-by-address variables. The initial value of c 
  is the input value of the carry bit. The final value of cout is the output 
  value of the carry bit. The final value of s is the output value of 
  the sum bit. And all values of x, y, c, and s should be either 0 or 1 only.
*/
void fullAdder (int x, int y, int *cout, int *s,int *c) {
  *s = (x ^ y) ^ *cout; // s = (x xor y) xor c_in.
  *c=*cout;//to take the second last bit of carry out
  *cout = (x & y) | (*cout & (x ^ y));  // c_out = (x and y) or (c_in and (x xor y))
}

/*
  Parameters X and Y are two integers which represent two 32-bit 
  binary numbers. c represents the carry bit and it is call-by-address.
  And its final value is returned to inidcate  overflow situation.
  Adder-Subtractor will return the sum, S, of X and Y. S is also a 32-bit binary number.
  Variable pos represents the poistion of the bit being processed. The least significant 
  bit is of position 0 and the most significant bit is of position 31. The value of 
  variable S is returned at the end of Adder-Subtractor. Variable x, y, and s represent 
  the current bit of X, Y, and S.
*/
 int adder( int X, int Y, int *cout,int*c,int M) {
	int S = 0; // At the end S=X+Y and its value is returned.
  int pos; // Position, from right to left. of the current bit to apply full adder.
  int x, y, s; // A single bit of X, Y, and S, respectively.
 
  for (pos=0; pos<32; ++pos) { // 32-bit Adder-Subtractor.
    x = X & 1; // Set x to the current bit of X.
    y = (Y & 1)^M; // Set y to the current bit of Y.
    // Perform Adder-Subtractor to add x, y , and the carry in c 
    // to yield the sum bit s and the carry out cout.
    // Note that c is a pointer to an integer.
    fullAdder(x, y, cout, &s,c);
    // The shift operation is to move the next processed bit of X and Y to the least significant bit.
    X = X >> 1; // Update X to shift its bits one position to the right-hand-side.
    Y = Y >> 1; // Update Y to shift its bits one position to the right-hand-side.
    // Place the sum bit s in sum to the appropriate position of S by different vlaue of pos.
    S = S | (s << pos);
}
  // Return the result sum.
  return S;
}

int main(void) {
	int X, Y, S,M; // To compute S=X+Y.
  int cout,c; // Carry in and carry out. 
  char op;
  int b=0;
  
  while (1){ // Continue to process the Adder-Subtractor until both input are 0's.  
    // Input two 32-bit integers.
    printf("Enter two integers between -2,147,483,648 and 2,147,483,647: ");
    scanf("%u %c %u", &X,&op, &Y);
    //to decide the value of M and cout by verify the op
    //if the op is + M=0, cout=0, and when op is - M=1, cout=1
    if(op=='+')
    {
    	M=0;
    	cout=0;
	}
	else if(op=='-')
	{
		M=1;
		cout=1;
	}
    if (X==0 && Y==0) break; // If both X and Y are 0, stop the loop and terminate the program. 
    
    // Perform binary Adder-Subtractor to add the two positive integers X and Y with carry_in c.
	// Store the final result in variable S.
    S = adder(X, Y, &cout,&c,M); // Call function adder().

    	printf("X = %-10d  Binary value: ", X); // Output decimal value of X with left alignment.
    	printBinary(X); // Output binary value of X.
    	printf("\n"); // Output a new line.
    	printf("Y = %-10d  Binary value: ", Y); // Output decimal value of Y with left alignment.
    	printBinary(Y); // Output binary value of Y.
    	printf("\n"); // Output a new line.
    	printf("S = %-10d  Binary value: ", S); // Output decimal value of the sum S with left alignment.
    	printBinary(S); // Output binary value of S.
    	printf("\n"); // Output a new line.
    //when X+Y=S or X-Y=S, print the sentence correct!Adder-Subtractor operation test X+Y=S or X-Y=S
    //when c^cout==1 it means that the poeration is overflow, so print the word overflow
	//on the other, when c^cout!=1, the operation is not overflow 
    if (X+Y==S&&op=='+'&&c^cout!=1||X-Y==S&&op=='-'&&c^cout!=1) printf("Correct! Adder-Subtractor operation test: %d %c %d = %d\n", X, op, Y, S);
    else if (X+Y==S&&op=='+'&&c^cout==1||X-Y==S&&op=='-'&&c^cout==1) printf("overflow");
	else  printf("Incorrect! Adder operation test: %d + %d != %d\n", X, Y, S);
    printf("-----------------------------------------------------\n"); // Print a separated line.
  }
  
  return 0;
}

