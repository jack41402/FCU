#include <stdio.h>

void bi(int n, char name){ // this function will print out the binary value
	int i = 0;
	int j = 0;
	int bit = 0;
	int m = 0;
	
	printf("%c = %-11d Binary value: ", name, n);
	for(i = 0; i < 32; i++){
		m = n;
		for(j = 0; j < 31 - i; j++){// we need to calculate 31st bit first.
			m = m >> 1; // right shift 
		}
		bit = m & 1;
		printf("%d", bit);
		if (i%4 == 3){//need to print space every 4 bits
			printf(" ");
		}	
			
	}
	
	
	printf("\n");
}

int main(){

	
	do{
		int X = 0;
		int Y = 0;
		char op = 0;
		int m = 0;
		int Cin = 0;
		int Cout = 0;
		int S = 0;
		int i = 0;
		int Xi = 0;
		int Yi = 0;
		int Si = 0;
		int ans = 0;
		int Xorg = 0;
		int Yorg = 0;
		
		printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648, 2,147,483,647): ");
		scanf("%d %c %d", &X, &op, &Y);
		if(X == 0 && Y == 0) break; // stop the program if both x and y are 0.
		Xorg = X;
		Yorg = Y;// to print out at the correct part.
		
		bi(X, 'X');
		bi(Y, 'Y');
		
		if (op == '-') m = 1;
		if (op == '+') m = 0;
		Cout = m;
		if (m == 0) ans = X + Y;
		if (m == 1) ans = X - Y;// caculate what will x+y or x-y will be
		
		for(i = 0; i < 32; i++){// caculate S
			Cin = Cout;
			Xi = X & 1;
			Yi = Y & 1;
			X = X >> 1;
			Y = Y >> 1;
			Si = (Xi ^ (Yi ^ m)) ^ Cin;
			Cout = (Xi & (Yi ^ m)) | (Cin & (Xi ^ (Yi ^ m)));// logic formula of a full adder
			S = (Si << i) | S;
		} 
		bi(S,'S');
		
		if (ans == S) printf("Correct! Adder-subtractor operation test: %d %c %d = %d\n", Xorg, op, Yorg, S);// checking is the caculation right
		if (Cin != Cout) printf("The addition-subtraction operation is overflow\n");// if Cin = Cout it mean it has overflow
		printf("--------------------------------------------------------------\n");
	} while(1);// keep redoing the program
} 
