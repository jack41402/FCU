#include<stdio.h>

void printBinary(int n) {
	int i; // loop vairable
	for (i=1; i<=32; i++) { // Output all 32 bits.
    	printf("%d", (n>>(32-i))&0X00000001); // Output a bit of n from left to right.
    	if (i%4==0) printf(" "); // Print a space every four bits.
  	}
}
void fullAdder (int x, int y, int *cout, int *s) {
  	*s = (x ^ y) ^ *cout; // s = (x xor y) xor c_in.
  	*cout = (x & y) | (*cout & (x ^ y)); // c_out = (x and y) or (c_in and (x xor y)).
}
int adder(int X,int Y,int *c,int m) {
	int S = 0; // At the end S=X+Y and its value is returned.
  	int pos; // Position, from right to left. of the current bit to apply full adder.
  	int x, y, s; // A single bit of X, Y, and S, respectively.
  	int cin, cout=m; //cout for the carry in, cin for remembering the penultimate carry in.
  	for (pos=0; pos<32; pos++) {
		x = X & 1; // Set x to the current bit of X, i.e., the least significant bit of X.
		y = (Y & 1)^m; // Set y to the current bit of Y, i.e., the least significant bit of Y. Also, use m to decide add or substract
		cin=cout;
    	fullAdder(x, y, &cout, &s);
    	X = X >> 1;
    	Y = Y >> 1;// Update X,Y to shift its bits one position to the right-hand-side.
    	S = S | (s << pos); // Place the sum bit s in sum to the appropriate position of S specified by pos.
  	}
  	*c=cin^cout; // confirm if S got overflow or not.
  	return S;
}
int main(void){
	int X,Y,S,c,m,verify_op=0;
	char op; 
	while(verify_op==0){
		printf("Enter \"X + Y\" or \"X - Y\" (X,Y: -2,147,483,648 to 2,147,483,648): ");
		scanf("%d %c %d", &X, &op, &Y);
		if(op=='+'||op=='-') verify_op=1; //verify if 'op' has been inserted correctly.
	}
	while(X!=0||Y!=0){
		if(op=='+') m=0;
		else if(op=='-') m=1;
		S = adder(X, Y, &c, m);
		printf("X = %-11d  Binary value: ",X);
		printBinary(X);
		printf("\n");
		printf("Y = %-11d  Binary value: ",Y);
		printBinary(Y);
		printf("\n");
		printf("S = %-11d  Binary value: ",S);
		printBinary(S);
		printf("\n");
	// Print the confirming message. The else case should not be executed.
		if (X+Y==S&&op=='+'||X-Y==S&&op=='-') printf("Correct! Adder-subtractor operation test: %d %c %d = %d\n", X, op, Y, S);
    	else printf("Incorrect! Adder operation test: %d %c %d != \n", X, op, Y, S);
   	// Print the overflow message.
    	if (c==1) printf("**** The addition-subtraction operation is overflow.\n");
    	printf("-----------------------------------------------------\n");
    	verify_op=0;
		while(verify_op==0){
		printf("Enter \"X + Y\" or \"X - Y\" (X,Y: -2,147,483,648 to 2,147,483,648): ");
		scanf("%d %c %d", &X, &op, &Y);
		if(op=='+'||op=='-') verify_op=1; //verify if 'op' has been inserted correctly.
		}
	}
	return 0;
}
