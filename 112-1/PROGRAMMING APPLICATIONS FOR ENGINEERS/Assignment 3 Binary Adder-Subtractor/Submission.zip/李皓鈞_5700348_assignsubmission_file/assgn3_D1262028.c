#include<stdio.h>

int X, Y;//The integers between -2,147,483,648 and 2,147,483,647.
int S;//The sum of X+Y or X-Y.
int i;//Variable integer.
int x, y;//The indivisual bits of X or Y.
int s;//The sum of indivisual bits of X or Y.
int M;//Used to idicate addiction or subtraction operation.
char op;//Stores '+' or '-' inputted by the user.
int c;//The carry-in bit or carry-out bit.
int v;//Carry-out of the second to last bit.

void printBinary(int n)
{
	int i;
	for(i=1; i<=32; ++i)//output 32 bits
	{
		printf("%d", (n>>(32-i))&1); // Output a bit of n from left to right.
		if(i%4==0)
		{
			printf(" ");// Print a space every four bits.
		}
	}
}

int main(void)
{
	do
	{
		printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648 to 2,147,483,647): ");
		scanf("%d %c %d", &X, &op, &Y);
		if(op=='+')//If it is an addition operation, M will be set to 0.
		{
			M=0;
		}
		else if(op=='-')//If it is a subtraction operation, M will be set to 1.
		{
			M=1;
		}
		c=M;//Sets the initial carry-in as M.
		S = 0;//Set S=0.
		for(i=1; i<=32; i++)
		{	
			x=X>>(i-1)&1;//Extracts the i-th bit from the right in the binary representation of X and store it in x.
			y=(Y>>(i-1)&1) ^ M;//Extracts the i-th bit from the right in the binary representation of Y and store it in y.
			s= (x ^ y) ^ c;
			c=(x & y) | (c & (x ^ y));
			if(i==31) 
			{
				v=c;//Sets v as the value of the second to last carry-out bit.
			}
			S=S|(s<<(i-1));//Used to construct the sum based on the individual bits of X and Y.
		}
		printf("X = %-10d  Binary value: ", X);
		printBinary(X);// Output binary value of X.
		printf("\n");	
		printf("Y = %-10d  Binary value: ", Y);
		printBinary(Y);// Output binary value of Y.
		printf("\n");
		printf("S = %-10d  Binary value: ", S);
		printBinary(S);// Output binary value of sum.
		printf("\n");
		printf("Correct! Adder-subtractor operation test: %d %c %d = %d", X, op, Y, S);//Prints out "X + Y = sum" or "X - Y = sum".
		printf("\n");
		if (c!=v)
		{
			printf("****The addition-subtraction operation is overflow.\n");//If the last and second to last carry-out bits are not the same, there is an overflow.
		}
		printf("-----------------------------------------------------\n");
	}
	while(X!=0||Y!=0);//Repeats the program until both X and Y are 0.
}
