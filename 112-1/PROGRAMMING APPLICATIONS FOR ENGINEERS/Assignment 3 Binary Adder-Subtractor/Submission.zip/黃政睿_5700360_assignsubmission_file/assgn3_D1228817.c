#include<stdio.h>

int main(){
	
int X, Y;//Integers with values between -2,147,483,648 and 2,147,483,647.
int i;//Controls the position.
int x, y;//The individual bits of X and Y.
int sum;//The sum of X+Y or X-Y.
int s;//The sum of individual bits of X and Y.
int M;//Used to indicate addition or subtraction operation.
char op;//Stores '+' or '-' inputted by the user.
int c;//The carry-in bit / carry-out bit.
int v;//Carry-out of the second to last bit.

do{
	
	sum=0;
	
	do{
		if(op!='+' && op!='-') printf("Please make sure the input is correct.\n");
		printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648 to 2,147,483,647): ");
		scanf("%d %c %d", &X, &op, &Y);
	}while(op!='+' && op!='-');//To make sure op is '+' or '-'.
	
if(op=='+'){//If it is an addition operation, M will be set to 0.
	M=0;
}
else if(op=='-'){//If it is a subtraction operation, M will be set to 1.
	M=1;
}

c=M;//Sets the initial carry-in as M.

printf("X = %d		Binary value: ", X);

for (i=1; i<=32; i++) { // Output all 32 bits.
    printf("%d", (X>>(32-i))&1); // Output a bit of X from left to right.
    if (i%4==0) printf(" "); // Print a space every four bits.
}
  
  printf("\n");
  
  printf("Y = %d		Binary value: ", Y);
  
for (i=1; i<=32; i++) { // Output all 32 bits.
    printf("%d", (Y>>(32-i))&1); // Output a bit of Y from left to right.
    if (i%4==0) printf(" "); // Print a space every four bits.
}
  
  printf("\n");
  
  for(i=1; i<=32; i++){
  	x=X>>(i-1)&1;//Extracts the i-th bit from the right in the binary representation of X and store it in x.
  	y=Y>>(i-1)&1;//Extracts the i-th bit from the right in the binary representation of Y and store it in y.
  	
	  
  	s=(x ^ (y^M)) ^ c;
  		c=(x & (y^M)) | (c & (x ^ (y^M)));
  		if(i==31) v=c;	//Sets v as the value of the second to last carry-out bit. 
  		sum=sum|(s<<(i-1));//Used to construct the sum based on the individual bits of X and Y.
  }
   

 printf("S = %d		Binary value: ", sum);

for (i=1; i<=32; i++) { // Output all 32 bits.
    printf("%d", (sum>>(32-i))&1); // Output a bit of sum from left to right.
    if (i%4==0) printf(" "); // Print a space every four bits.
}
  
  printf("\n");
  
  
if(M==0){//When it's an addition operation.
  	if(X+Y==sum){//Checks if the addition operation has the same result as the binary adder.
  	printf("Correct! ");
  }
  else{
  	printf("Incorrect! ");
  }
}  
  
else{//When it's a subtraction operation.
  	if(X-Y==sum){//Checks if the subtraction operation has the same result as the binary subtractor.
  	printf("Correct! ");
  }
  else{
  	printf("Incorrect! ");
  }
}
	
	printf("Adder-subtractor operation test: %d %c %d = %d", X, op, Y, sum);//Prints out "X + Y = sum" or "X - Y = sum".
	printf("\n");
	
	if (c!=v) printf("**** The addition-subtraction operation is overflow.\n");//If the last and second to last carry-out bits are not the same, there is an overflow.
	printf("-----------------------------------------------------\n");
}while(X!=0||Y!=0);//Repeats the program until both X and Y are 0

}
