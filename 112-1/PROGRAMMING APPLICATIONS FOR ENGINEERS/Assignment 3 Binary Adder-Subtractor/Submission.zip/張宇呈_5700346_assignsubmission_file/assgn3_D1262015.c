#include <stdlib.h>
#include <stdio.h>

void printChar(int n, char c) {
  int i; 
 
  for (i=0; i<n; i++) printf("%c", c); 
}

void printBinary(int n) {
    int i ;
    for (i = 31; i >= 0; i--) {
        if (i % 4 == 3 && i != 31) {
            printf(" %d", (n >> i) & 0x01);
        } else {
            printf("%d", (n >> i) & 0x01);
        }
    }
}


void fullAdder(int x, int y, int *c, int *s) {
  *s = (x ^ y) ^ *c;
  *c = (x & y) | (*c & (x ^ y));
}

int adder(unsigned int X, unsigned int Y, int M, int *V) {
  unsigned int S = 0;
  int carryin = M, carryout;
  int weizhi;

  for (weizhi = 0; weizhi <= 31; weizhi++) {
    int x = X & 1;
    int y = Y & 1;
    y = y ^ M;

    carryout = carryin;
    fullAdder(x, y, &carryout, V);
    carryin = carryout;
    X = X >> 1;
    Y = Y >> 1;
    S = S | (*V << weizhi);
  }
  return S;
}

int main(void) {
  int X, Y, S, M, V;
  char AAS;

  while (1) {
    printf("Enter \"X + Y\" or \"X - Y\" (X, Y: -2,147,483,648 to 2,147,483,647) : ");
    scanf("%d %c %d", &X, &AAS, &Y);
    if (AAS == '+') M = 0;
    else M = 1;
    S = adder(X, Y, M, &V);
    if (X == 0 && Y == 0) break;
    printf("X = %-11d  Binary value: ", X); 
    printBinary(X); 
    printf("\n");
    printf("Y = %-11d  Binary value: ", Y); 
    printBinary(Y); 
    printf("\n"); 
    printf("S = %-11d  Binary value: ", S); 
    printBinary(S); 
    printf("\n"); 
    if (M==0)
	  if (X+Y==S) printf("Correct! Adder-subtractor operation test: %d %c %d = %d\n", X, AAS, Y, X+Y);
	  else printf("Incorrect! Adder-subtractor operation test: %d %c %d = %d != %d\n", X, AAS, Y, X+Y, S);  
    else if (M==1)
	  if (X-Y==S) printf("Correct! Adder-subtractor operation test: %d %c %d = %d\n", X, AAS, Y, X-Y);
      else printf("Incorrect! Adder-subtractor operation test: %d %c %d = %d != %d\n", X, AAS, Y, X-Y, S);
  
    
    if (V==1) printf("**** The addition-subtraction operation is overflow.\n"); 
    printf("\n");
    printChar(50, '-');
    printf("\n");
  }

  return 0;
}

