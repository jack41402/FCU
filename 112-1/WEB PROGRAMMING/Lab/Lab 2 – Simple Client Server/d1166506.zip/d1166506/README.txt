In d1166506:
	in basic:
		run server.py and client.py to create tcp/ip connection
	with gui:
		run start.py to generate gui and automatically connect server and client