x = -5:0.1:5;
y = newquot(x)