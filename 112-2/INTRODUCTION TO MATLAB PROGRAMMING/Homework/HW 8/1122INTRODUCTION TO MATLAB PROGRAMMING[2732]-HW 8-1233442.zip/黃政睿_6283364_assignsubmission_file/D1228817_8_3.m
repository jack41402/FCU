n=1;
sum=0;

while true

    sum=sum+n^2;
    if sum>1000
        break
    end

    n=n+1;


end

n=n-1;
display(n);

sum-(n+1)^2


