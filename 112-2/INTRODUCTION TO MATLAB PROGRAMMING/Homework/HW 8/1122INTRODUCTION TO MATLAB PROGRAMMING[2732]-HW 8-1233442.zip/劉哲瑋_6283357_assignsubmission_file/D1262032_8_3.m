sum=0;
n=1;
while sum<=1000
    sum=sum+n^2;
    n=n+1;
end
n=n-2
sum-(n+1)^2