ans = 0;
n = 0;
while ans + (n + 1)^2 <= 1000
    n = n + 1
    ans = ans + n^2
end


