h=1;

while h>=10.^(-6)
y= newquot(1,h);
h=h.*10.^(-1);
end
y