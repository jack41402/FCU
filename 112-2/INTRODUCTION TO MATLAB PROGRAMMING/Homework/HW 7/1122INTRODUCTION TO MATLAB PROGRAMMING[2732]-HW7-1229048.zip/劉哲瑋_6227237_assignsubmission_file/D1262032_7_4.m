x = input('');
y = input('');
x = x
y = y
swop(x, y);
function swop(x, y)
temp = x;
x = y;
y = temp;
fprintf("(x, y)=\n     %d     %d\n", x, y)
end
