function y = f(x)
y = x^3 + x - 3;
