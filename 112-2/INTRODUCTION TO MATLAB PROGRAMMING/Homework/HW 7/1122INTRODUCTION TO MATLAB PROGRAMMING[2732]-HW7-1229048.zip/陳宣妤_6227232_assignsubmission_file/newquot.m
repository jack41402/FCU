f = @(x) x^3;
newquot(f);
