function y=D1228817_newquot(y1, y2, h)

         y=(y1-y2)/h;

end

