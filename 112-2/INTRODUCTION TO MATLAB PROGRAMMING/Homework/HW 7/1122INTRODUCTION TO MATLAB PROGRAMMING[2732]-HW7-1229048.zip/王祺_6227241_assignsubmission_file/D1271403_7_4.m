x = input("x = \n    ");
y = input("y = \n    ");

[x, y] = swop(x, y);
fprintf("(x,y)=\n    %d %d\n", x, y);

function [y, x] = swop(x, y)
end