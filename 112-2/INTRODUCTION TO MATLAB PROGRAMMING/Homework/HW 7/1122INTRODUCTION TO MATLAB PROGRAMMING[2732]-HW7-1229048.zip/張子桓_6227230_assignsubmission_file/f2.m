function y = f2(x)
y = 1 + exp(-0.2*x) * sin(x + 2);
end