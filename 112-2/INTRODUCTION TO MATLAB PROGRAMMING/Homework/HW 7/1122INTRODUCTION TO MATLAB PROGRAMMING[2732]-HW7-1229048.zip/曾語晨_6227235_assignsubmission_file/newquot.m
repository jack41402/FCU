function y = newquot(x)
    % Define the function f(x) = x^3
    y = x^3;
end
