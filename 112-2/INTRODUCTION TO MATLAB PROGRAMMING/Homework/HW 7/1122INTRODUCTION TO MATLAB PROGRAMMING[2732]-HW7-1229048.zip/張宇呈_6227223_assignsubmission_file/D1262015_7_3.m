f = @(x) x^3;
x = 1;
newquot(f, x);