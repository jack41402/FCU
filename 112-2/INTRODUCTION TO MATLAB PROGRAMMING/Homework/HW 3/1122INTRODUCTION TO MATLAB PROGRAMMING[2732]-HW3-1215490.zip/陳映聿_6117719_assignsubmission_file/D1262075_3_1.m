fprintf("Enter A:")
a=input('');
fprintf("\nEnter B:")
b=input('');
fprintf("\nEnter C:")
c=input('');
p=[a b c];
root=roots(p)
root1=root(1)
root2=root(2)




