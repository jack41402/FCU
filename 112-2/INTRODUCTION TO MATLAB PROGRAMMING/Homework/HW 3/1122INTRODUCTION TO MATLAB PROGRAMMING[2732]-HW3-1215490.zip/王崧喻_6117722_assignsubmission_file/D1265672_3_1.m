a = input('');
b = input('');
c = input('');
D = b^2-(4*a*c);

root1  = (-b+sqrt(D))/(2*a)
root2  = (-b-sqrt(D))/(2*a)