A = input("Enter A:\n");
B = input("Enter B:\n");
C = input("Enter C:\n");
D = sqrt(B^2-(4*A*C));

root1=(-B+(D))/(2*A)
root2=(-B-(D))/(2*A)








