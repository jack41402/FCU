a = input('Enter A: \n');
b = input('Enter B: \n');
c = input('Enter C: \n');

p = [a; b; c];
root = roots(p);
root_1 = root(1)
root_2 = root(2)