fprintf('Enter A:')
a = input('');
fprintf('Enter B:')
b = input('');
fprintf('Enter C:')
c = input('');
p=[a b c];
root = roots(p)
root1 = root(1)
root2 = root(2)