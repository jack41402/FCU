fprintf('Enter A:\n');
A = input('');
fprintf('Enter B:\n');
B = input('');
fprintf('Enter C:\n');
C = input('');
p = [A B C];
root = roots(p);
root1 = root(1)
root2 = root(2)

