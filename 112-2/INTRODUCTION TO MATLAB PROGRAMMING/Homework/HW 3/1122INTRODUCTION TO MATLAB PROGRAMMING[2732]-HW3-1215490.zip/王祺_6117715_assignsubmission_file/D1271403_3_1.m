a = input("Enter A: \n");
b = input("Enter B: \n");
c = input("Enter C: \n");
D = sqrt(b^2-4*a*c);
root1 = (-b+D)/(2*a)
root2 = (-b-D)/(2*a)




