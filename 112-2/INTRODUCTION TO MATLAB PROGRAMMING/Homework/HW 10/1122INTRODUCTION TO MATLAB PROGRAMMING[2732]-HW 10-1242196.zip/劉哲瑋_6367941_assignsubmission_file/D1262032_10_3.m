i=-5:0.1:5;
y=newquot(i, 10^(-3))