a = 1 & -1;
b = 13 & ~(-6);
c = 0 < -2 | 0;
d = ~[1 0 2]*3;
e = 0 <= 0.2 <= 0.4;
f = 5>4>3;
g = 2>3&1;

fprintf("A.")
disp(a);
fprintf("B.")
disp(b);
fprintf("C.")
disp(c);
fprintf("D.")
disp(d);
fprintf("E.")
disp(e);
fprintf("F.")
disp(f);
fprintf("G.")
disp(g);