x = [1 2 5 0 5];
d = find(x==max(x));
x(d)=[]
