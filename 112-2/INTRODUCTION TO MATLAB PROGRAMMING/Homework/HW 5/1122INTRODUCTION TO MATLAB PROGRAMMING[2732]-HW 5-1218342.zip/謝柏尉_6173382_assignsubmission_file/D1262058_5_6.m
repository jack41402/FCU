x= [1 2 5 0 5];
ind = find(x==max(x));
x(ind) = [];
x
