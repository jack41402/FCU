A=1&-1;
B=13&~(-6);
C=0<-2|0;
D=~[1 0 2]*3;
E= 0<=0.2<=0.4;
F=5>4>3;
G=2>3&1;

fprintf("A. %d", A);

fprintf("\nB. %d", B);

fprintf("\nC. %d", C);

fprintf("\nD. %d %d %d", D);

fprintf("\nE. %d", E);

fprintf("\nF. %d", F);

fprintf("\nG. %d", G);
