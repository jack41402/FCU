x = [1 2 5 0 5];
Max = max(x); 
indice = find(x == Max);  
x(indice) = []