a = 1 & -1 ;
fprintf('A. %d',a)
b = 13 & ~(-6);
fprintf('\nB. %d',b)
c = 0 < -210;
fprintf('\nC. %d\n',c)
d = ~ [1 0 2] * 3;
fprintf('D. ')
fprintf('%d ',d)
e = 0 <= 0.2 <= 0.4;
fprintf('\nE. %d',e)
f = 5 > 4 > 3;
fprintf('\nF. %d',f)
g = 2 > 3 & 1;
fprintf('\nG. %d',g)



