x = [1 2 5 0 5];
max_value = max(x);
position = find(x==max_value);
x(position)=[]
