x = [1 2 5 0 5];
x(x == max(x)) = [];
disp(x);
