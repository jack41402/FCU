a=[1 0 2];
b=[0 2 2];

a ~= b
a < b
a < b < a
a < b < b
a | (~a)
b & (~b)
a(~(~b))
a = b == a
