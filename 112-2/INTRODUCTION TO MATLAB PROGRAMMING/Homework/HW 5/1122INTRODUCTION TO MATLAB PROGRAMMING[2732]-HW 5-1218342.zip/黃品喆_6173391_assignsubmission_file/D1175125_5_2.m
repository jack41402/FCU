%5.2
a ~= b
a < b 
a < b < a 
a < b < b
a | (~a)
b & (~b)
a(~(~b))
a = b ==a