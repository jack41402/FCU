x = [1 2 5 0 5];
a = find(x == max(x));
x(a) = [];
x