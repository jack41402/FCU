fprintf("A. %d\n\n",1 & -1);
fprintf("B. %d\n\n",13 & ~(-6));
fprintf("C. %d\n\n",0 < -2|0);
fprintf("D. %d %d %d\n\n",~[1 0 2] * 3);
fprintf("E. %d\n\n",0 <= 0.2 <= 0.4);
fprintf("F. %d\n\n",5 > 4 > 3);
fprintf("G. %d\n\n",2 > 3 & 1);
