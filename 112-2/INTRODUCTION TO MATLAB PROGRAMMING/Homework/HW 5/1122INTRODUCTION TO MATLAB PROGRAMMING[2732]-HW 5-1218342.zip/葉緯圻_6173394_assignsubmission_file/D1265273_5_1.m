a=1&-1;
fprintf("A. %d\n", a)
b=13 & ~(-6);
fprintf("B. %d\n", b)
c=0< -2|0;
fprintf("C. %d\n", c)
d=~[1 0 2] *3;
fprintf("D. %d %d %d", d)
e=0<=0.2<=0.4;
fprintf("\nE. %d\n", e)
f=5 > 4 > 3;
fprintf("F. %d\n", f)
g=2>3&1;
fprintf("G. %d", g)