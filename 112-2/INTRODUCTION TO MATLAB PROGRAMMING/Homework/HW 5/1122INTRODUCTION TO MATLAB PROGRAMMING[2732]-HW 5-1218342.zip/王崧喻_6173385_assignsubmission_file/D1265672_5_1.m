fprintf("A. %d\n", 1&-1)
fprintf("B. %d\n", 13&~(-6))
fprintf("C. %d\n", 0<-2|0)
a = ~[1 0 2] * 3;
fprintf("D. ")
fprintf("%d", a(1:3))
fprintf("\nE. %d\n", 0<=0.2<=0.4)
fprintf("F. %d\n", 5>4>3)
fprintf("G. %d\n", 2>3&1)