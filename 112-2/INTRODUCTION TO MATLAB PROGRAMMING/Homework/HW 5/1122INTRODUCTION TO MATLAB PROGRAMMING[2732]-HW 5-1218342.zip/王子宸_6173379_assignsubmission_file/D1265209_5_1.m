A = 1 & -1;
fprintf("A. %d\n",A)
B = 13 & ~(-6);
fprintf("B. %d\n",B)
C = 0 <-2|0;
fprintf("C. %d\n",C)
D = ~[1 0 2] * 3;
fprintf("D.")
fprintf("%d",D)
fprintf("\n")
E = 0 <= 0.2 <= 0.4;
fprintf("E. %d\n",E)
F = 5 > 4 > 3;
fprintf("F. %d\n",F)
G = 2 > 3 & 1;
fprintf("G. %d\n",G)
