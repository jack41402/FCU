x = [1 2 5 0 5];
max = find(x==max(x));
x(max) = [];
x
