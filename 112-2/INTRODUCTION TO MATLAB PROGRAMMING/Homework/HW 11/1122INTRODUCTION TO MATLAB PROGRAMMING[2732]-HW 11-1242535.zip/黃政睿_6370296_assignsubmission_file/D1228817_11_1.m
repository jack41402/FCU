A={'Walden Pond', 'June 13, 1997'; [60 72 65], [55 57 56; 54 56 55; 52 55 53]};
cellplot(A);

