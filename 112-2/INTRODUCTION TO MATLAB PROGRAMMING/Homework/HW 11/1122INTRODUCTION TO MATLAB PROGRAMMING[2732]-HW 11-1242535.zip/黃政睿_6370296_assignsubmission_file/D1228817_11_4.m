bridge(1).Location='Smith St.';
bridge(1).Max_load=80;
bridge(1).Year_built=1928;
bridge(1).Due_for_maintenance=2011;

bridge(2).Location='Hope Ave.';
bridge(2).Max_load=90;
bridge(2).Year_built=1950;
bridge(2).Due_for_maintenance=2013;

bridge(3).Location='Clark St.';
bridge(3).Max_load=85;
bridge(3).Year_built=1933;
bridge(3).Due_for_maintenance=2012;

bridge(4).Location='North Rd.';
bridge(4).Max_load=100;
bridge(4).Year_built=1960;
bridge(4).Due_for_maintenance=2012;

bridge(5).Location='Shore Rd.';
bridge(5).Max_load=85;
bridge(5).Year_built=1997;
bridge(5).Due_for_maintenance=2014;