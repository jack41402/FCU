clear;
student(1).Name='John Smith';
student(1).SSN='392-77-1786';
student(1).Email='smithj@myschool.edu';
student(1).Tests=[67 75 84];

student(2).Name='Mary Jones';
student(2).SSN='431-56-9832';
student(2).Email='jonesm@myschool.edu';
student(2).Tests=[84 78 93];