%ok

student(1).name = '';
student(1).SSN = '';
student(1).email = '';
student(1).tests = [];

student(1).name = 'John Smith';
student(1).SSN = '392-77-1786';
student(1).email = 'smithj@myschool.edu';
student(1).tests = [67, 75, 84];

student(2).name = '';
student(2).SSN = '';
student(2).email = '';
student(2).tests = [];

student(2).name = 'Mary Jones';
student(2).SSN = '431-56-9832';
student(2).email = 'jonesm@myschool.edu';
student(2).tests = [84, 78, 93];

disp(student);