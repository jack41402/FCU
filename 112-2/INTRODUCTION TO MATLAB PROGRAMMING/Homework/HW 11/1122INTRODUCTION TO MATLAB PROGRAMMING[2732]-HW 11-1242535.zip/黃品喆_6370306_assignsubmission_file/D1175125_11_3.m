clear student;
Student(1)=struct('Name', 'John Smith', 'SSN', '392-77-1787', 'Email', 'smithj@myschool', 'Tests',[67 75 84] );
Student(2)=struct('Name', 'Mary Jones', 'SSN', '431-56-9832', 'Email', 'jonesm@myschool', 'Tests',[84 78 93] );