clear A
A=cell(2,2);
A{1,1}='Waldn Pond';
A{1,2}='June 13, 1997';
A{2,1}=[60 72 65];
A{2,2}=[55 57 56; 54 56 55; 52 55 53];

cellplot(A)