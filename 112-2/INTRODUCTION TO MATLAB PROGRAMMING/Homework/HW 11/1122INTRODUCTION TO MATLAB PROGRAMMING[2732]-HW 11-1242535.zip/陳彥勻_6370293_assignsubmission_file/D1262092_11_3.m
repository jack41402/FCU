clear student;
student(1) = struct('name', 'John Smith', 'SSN', '392-77-1786', 'Email', 'smithj@myschool.edu', 'Tests', [67, 75, 54]);
student(2) = struct('name', 'Mary Jones', 'SSN', '431-56-9832', 'Email', 'jonesm@myschool.edu', 'Tests', [84 ,78 ,93]);
student(1).Tests