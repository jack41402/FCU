clear all;close all;
A(1, :) = {'Walden Pond', '13 june,1997'};
A(2, :) = {[60, 72, 65], [55, 57, 56; 54, 56, 55; 52, 55, 53]};

cellplot(A)
