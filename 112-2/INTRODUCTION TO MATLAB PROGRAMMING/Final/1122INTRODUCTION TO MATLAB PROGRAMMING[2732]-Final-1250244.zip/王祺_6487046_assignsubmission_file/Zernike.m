function c = Zernike(z,u)
z = 2.*p.^2.*sin(u).*cos(u)
end