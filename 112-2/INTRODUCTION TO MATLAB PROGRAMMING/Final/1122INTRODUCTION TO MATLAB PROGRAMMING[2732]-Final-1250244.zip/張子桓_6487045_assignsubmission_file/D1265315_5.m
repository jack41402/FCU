C = readcell("test_score1.xls")
avg_1= mean(:,5);
avg_2= mean(:,6);
