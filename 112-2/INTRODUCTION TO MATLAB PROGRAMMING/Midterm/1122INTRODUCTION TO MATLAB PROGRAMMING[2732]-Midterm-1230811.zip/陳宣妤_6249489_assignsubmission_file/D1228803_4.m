function D1228803_4()
    function four  = func(f)
    
        steps = 0;
        x = input( 'Initial guess: ');
        n = (0:20); 
        
        for steps=1:19 
            
            steps = steps + 1; 
            disp( [n x_n] ) 
            
           rats(x_n, 20)
        end 
    end
    
end
