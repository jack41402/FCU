function y = func(n, a)
    y = (n.*a.^n)./factorial(n+1);
end
