fprintf('n      x_n\n')
fprintf("%d", func)