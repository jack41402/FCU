n = 0;
a = 2;
while n<21
    
    fprintf("%d %30.d\n",n,X_n)
    X_n = func(n);
    n = n+1;
end