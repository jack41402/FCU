f=@func
a=2;
n=0:20;
for n=0:20
S = rats(f,n)
m=[0+n,S]
end
