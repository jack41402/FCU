function y=func(n,a)
y=@(n)n*a^n/(n+1)
end

