uc = [ 6 2 1;
       2 5 4;
       4 3 2;
       9 7 3]

pc = [10 12 13 15;
       8 7 6 4;
      12 10 13 9;
       6 4 11 5]
qc = uc.*pc.*1000

fprintf('Quarterly cost for materials: ');
fprintf('Quarterly cost for labor: ');
fprintf('Quarterly cost for transportation: ');
fprintf('Total costs for materials');
fprintf('Total costs for labor');
fprintf('Total costs for transportation');