function y = func(x)
y = 2.^x;
end
