
a = input("input a:");

n = input("input n:");

fprintf("n  xn");

