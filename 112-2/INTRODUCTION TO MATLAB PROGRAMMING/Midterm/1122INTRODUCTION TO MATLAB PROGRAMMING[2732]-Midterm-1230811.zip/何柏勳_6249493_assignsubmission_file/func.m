

function SUB_fuc result 
    x = @(n) n*a^n ./ (n+1) ;
    result = x;
end
