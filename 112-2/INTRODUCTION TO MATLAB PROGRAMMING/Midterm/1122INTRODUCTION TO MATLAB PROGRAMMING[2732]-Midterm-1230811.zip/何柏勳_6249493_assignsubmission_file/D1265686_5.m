

A = l*2*r + r^2;



