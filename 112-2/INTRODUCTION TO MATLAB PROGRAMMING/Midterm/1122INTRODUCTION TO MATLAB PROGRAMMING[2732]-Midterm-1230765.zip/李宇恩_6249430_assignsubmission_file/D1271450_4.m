a=2;
n=0:20;
x=@(n)n*a^n/(n+1)
S = rats(x,20)
fprintf("");