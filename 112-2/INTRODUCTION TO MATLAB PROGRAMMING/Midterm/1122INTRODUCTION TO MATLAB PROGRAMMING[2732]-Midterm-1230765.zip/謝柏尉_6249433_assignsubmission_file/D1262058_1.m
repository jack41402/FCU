s = (-pi/2):pi/20:(pi/2);
t = 0:0.2:4;
a = 5;
b = 2;
fprintf("a = \n");
for i = 1:20
    (exp(-0.2.*t).*sin(b.*s)+log(t+1)).*(cos(2.*s)).^2
    if(i == 10)
       printf("\n")
    end
end
fprintf("c = \n");
disp((exp(t)+sin(s))./b)
fprintf("b = \n");
(arcsine(a.*t)+log(t.^2+2.*t+1)).*tan(s./2)



