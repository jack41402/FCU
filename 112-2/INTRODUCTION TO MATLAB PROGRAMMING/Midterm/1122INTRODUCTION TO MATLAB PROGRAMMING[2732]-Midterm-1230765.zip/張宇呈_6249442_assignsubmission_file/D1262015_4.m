
a = 2;
xn = func(n, a);
fprintf('n = %d, Xn = %s\n', n, rats(xn, 1));
