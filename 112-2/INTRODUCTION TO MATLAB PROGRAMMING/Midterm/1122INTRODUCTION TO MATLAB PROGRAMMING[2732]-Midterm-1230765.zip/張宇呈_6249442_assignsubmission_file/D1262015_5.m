

A = 2000; 
cost_curved = 50;
cost_straight = 40; 
L = 0:0.01:100;
R = 0:0.01:100;
2.*L.*R + (pi.*R.^2)./2 == 2000
cost = @(R) 50*pi.*R + 40*(2.*R + 2.*L);


R_low = 0;
R_up = 100;

R_opt = fminbnd(cost, R_low, R_up);

L_opt = (A - pi*R_opt^.2)/(2*R_opt);

C_min = cost(R_opt);

fprintf('The optimal values are R = %.2f ft and L = %.2f ft.\n', R_opt, L_opt);
fprintf('The minimum cost is $%.2f.\n', C_min);