L =  (2000 - (pi*(R.^2)*0.5))/2/R
R = 0:0.01:29
cost = @(R, L) 40.*(2*L + 4*R) + 50*pi*R;
[R_min, L_min] = fminbnd(cost);
min_cost = 40.*(2*L_min + 4*R_min) + 50*pi*R_min;