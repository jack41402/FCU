a = 2;
n = 0:20;
x_n = func(a, n);
for n = 0:20
    fprintf('%d %d\n', n, x_n)
end
