function y = Xn(x)
    a = 2;
    n = (0:20);    
    Xn = (n .* a.^n) / factorial(n + 1);
    