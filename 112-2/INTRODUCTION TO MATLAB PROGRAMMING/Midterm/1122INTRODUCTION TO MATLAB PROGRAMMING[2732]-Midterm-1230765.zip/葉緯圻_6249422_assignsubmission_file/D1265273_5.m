g = -pi/2 : pi/20 : pi/2;
t = 0: 0.2: 4;
e = 2;
d = 5;
fun = @(x) (exp(-0.2.*t).*sin(e.*x)+log(t+1)).*(cos(2.*x)).^2;
fprintf('Colums 1 through 10\n')
for i=1:10
    fprintf('%1.4f', fun(g))
end