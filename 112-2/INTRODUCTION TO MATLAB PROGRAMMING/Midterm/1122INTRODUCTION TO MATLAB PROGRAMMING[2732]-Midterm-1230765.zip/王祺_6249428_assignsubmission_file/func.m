function rats(x_n, strlen)
x_n = n.*a^n./factorial(n+1);
end
n = 0:1:20;
a = 2;
fprintf("n x_n", n, x_n)