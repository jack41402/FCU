function x = func(a,n)
x=(n.*a.^n)/(n+1)
end