n=0:20;
a=2;
func(a,n);
rats(x,20);
fprintf('n        x_n');
fprintf('%d      %s',n,rats);
