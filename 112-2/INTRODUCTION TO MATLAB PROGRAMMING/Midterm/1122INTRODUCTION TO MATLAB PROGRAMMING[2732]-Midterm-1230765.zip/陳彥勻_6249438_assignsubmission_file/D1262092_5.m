f=@(L) L*2*R+(R^2)*pi/2;
%(a)
fminbnd(f,0,2000)
