function x = SUB_function
    s = 0;
    a = 2;
    x = 0;
    for n = 0:20
        s = s.*(n+1);
        x = n.*(a^n)/s;
    end
end
