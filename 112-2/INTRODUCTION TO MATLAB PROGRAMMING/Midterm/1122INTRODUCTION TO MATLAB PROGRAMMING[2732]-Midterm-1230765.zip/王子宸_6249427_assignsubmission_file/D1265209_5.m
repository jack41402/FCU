A = L.*(2.*R) + (R^2).*pi/2;

A = 2000;

R_min = 

L_min = 

min_cost = L.*2.*40+2.*R.*2.*40+2.*R.*pi.*50;