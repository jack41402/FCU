fprintf('n      Xn')
for i = 0:20
    fprintf('\n')
    fprintf('%d       %d',i,func)
end
