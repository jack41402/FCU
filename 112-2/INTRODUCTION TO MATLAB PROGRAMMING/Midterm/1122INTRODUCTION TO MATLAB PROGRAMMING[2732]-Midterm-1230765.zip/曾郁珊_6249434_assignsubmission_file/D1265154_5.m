fun = @(R,L)2*R*L + R^2 *pi.*1/2

R = 0.01;
L = 0.01;
[R_min] = fminbnd(fun,R,L)
[L_min] = fminbnd(fun,R,L)

