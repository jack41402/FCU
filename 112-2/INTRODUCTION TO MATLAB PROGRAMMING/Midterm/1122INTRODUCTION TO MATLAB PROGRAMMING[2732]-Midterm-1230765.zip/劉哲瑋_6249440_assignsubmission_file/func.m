function result=f(a, n)
    result=n*(a^n)/factorial(n+1);
end