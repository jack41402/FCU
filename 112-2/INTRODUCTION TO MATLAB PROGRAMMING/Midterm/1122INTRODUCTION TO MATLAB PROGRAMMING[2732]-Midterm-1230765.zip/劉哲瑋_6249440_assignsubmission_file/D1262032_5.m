%fminbnd(cost)
function result=cost(L, R)
area=@(L, R) 2.*R.*L+pi.*(R.^2)./2-2000;
[a b]=fzero(area, 0.01, 0.01)
%fminbnd((2.*a+2.*b).*40+pi.*b.*50, );
end