n = 0:1:20;
a = 2;
for n<21
    fprintf("%d %d",n,X_n)