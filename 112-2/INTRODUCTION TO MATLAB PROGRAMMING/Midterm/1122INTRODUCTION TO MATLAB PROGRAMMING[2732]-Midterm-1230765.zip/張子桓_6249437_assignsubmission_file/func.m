function y = func(x)
n = 0:1:20;
a = 2;
X_n =  n.*a.^n./factorial(n+1);
rats(X_n,25)
end