clear all
clc
n=20;
a=2;
func(n,a)
