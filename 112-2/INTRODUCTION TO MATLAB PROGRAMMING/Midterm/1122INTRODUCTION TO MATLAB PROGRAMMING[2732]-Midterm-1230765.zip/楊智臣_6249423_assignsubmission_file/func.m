function y = func(a, n)
    y = (n * a ^ n) / factorial(n + 1);
end