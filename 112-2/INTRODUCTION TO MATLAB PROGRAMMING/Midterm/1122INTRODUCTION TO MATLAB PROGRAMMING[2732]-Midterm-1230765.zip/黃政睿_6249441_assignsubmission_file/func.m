function x_n=func(a, n)

    x_n=n*(a^n)/factorial(n+1);

end

%D1228817