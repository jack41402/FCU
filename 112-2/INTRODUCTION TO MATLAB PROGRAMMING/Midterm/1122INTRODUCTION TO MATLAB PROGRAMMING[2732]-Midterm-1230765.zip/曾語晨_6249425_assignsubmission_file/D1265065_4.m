format rat
%s = s + x.^n/myfactorial(n); 
while i < 20
n = 0;
ans = (n.*x)./myfactorial(n);
n = n + 1; 
fprintf('n       x_n');
fprintf('%d %d', n, ans);
end
function a = myfactorial(i)
a = 1 ; 
for i = 0:20
    a = a*i ; 
end
end