L = 0:0.01:100;
R = 0:0.01:10;
A=  @(R,L) 2.*R.*L+pi.*R.*R./2;
%costs = 40.*2.*R.*L+50.*pi.*R.*R./2;
fminbnd(A,R,L)