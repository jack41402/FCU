#include "Node.h"

Node::Node() : elem(0), prev(nullptr), next(nullptr) {}

Node::Node(int value) : elem(value), prev(nullptr), next(nullptr) {}