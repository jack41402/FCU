#include "Node.h"
#include <iostream>

// Constructor implementation
Node::Node(int val) : elem(val), next(NULL), prev(NULL) {}
