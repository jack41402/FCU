#include "Node.h"

using namespace std;

Node::Node() : elem(0), prev(NULL), next(NULL) {}

Node::Node(int data) : elem(data), prev(NULL), next(NULL) {}

