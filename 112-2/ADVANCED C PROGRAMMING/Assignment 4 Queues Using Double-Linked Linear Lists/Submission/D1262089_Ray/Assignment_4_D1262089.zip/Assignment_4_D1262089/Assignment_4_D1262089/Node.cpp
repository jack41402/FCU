#include <cstdlib>
#include "Node.h"


Node::Node(){ elem=0; prev=NULL; next=NULL; }
Node::Node(int value){ elem=value; prev=NULL; next=NULL; }
