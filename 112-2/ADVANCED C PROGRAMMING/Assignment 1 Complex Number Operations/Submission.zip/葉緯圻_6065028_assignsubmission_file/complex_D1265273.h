//creat a struct name complex 
typedef struct{
	float re;
	float im;
}complex;

complex add (complex, complex);//The title of add function

complex minus (complex, complex);//The title of minus function

complex multi (complex, complex);//The title of multi funcction

complex divide (complex, complex);//The title of divide function

float absComplex (complex);//The title of absComoplex function

complex r2c (float);//The title of r2c function

void printcomplex(complex);//The title of print complex function
