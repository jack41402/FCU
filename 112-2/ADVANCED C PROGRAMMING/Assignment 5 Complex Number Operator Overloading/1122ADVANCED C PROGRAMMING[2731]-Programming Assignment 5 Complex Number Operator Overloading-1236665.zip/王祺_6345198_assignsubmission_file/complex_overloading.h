using namespace std;
// Declaration of the Complex class
class Complex{
	// Friend functions to allow direct access to class members for these non-member operators.
	friend ostream& operator <<(ostream& , const Complex& );
	friend istream& operator >>(istream& , Complex& );
	friend Complex operator +(const double&, const Complex&);
	friend Complex operator -(const double&, const Complex&);
	friend Complex operator *(const double&, const Complex&);
	friend Complex operator /(const double&, const Complex&);
	friend bool operator ==(const double&, const Complex&);
	friend bool operator !=(const double&, const Complex&);
	
	public:
		// Constructors
		Complex(double=0.0, double=0.0);
		Complex(const Complex&);
		// Arithmetic operators using both double and Complex types
		Complex operator +(const double&);
		Complex operator +(const Complex&);
		
		Complex operator -(const double&);
		Complex operator -(const Complex&);
		
		Complex operator *(const double&);
		Complex operator *(const Complex&);
		
		Complex operator /(const double&);
		Complex operator /(const Complex&);
		// Comparison operators
		bool operator ==(const double&);
		bool operator ==(const Complex&);
		
		bool operator !=(const double&);
		bool operator !=(const Complex&);
		 // Assignment operators
		Complex& operator =(const double&);
		Complex& operator =(const Complex&);
		 // Compound assignment operators
		Complex& operator +=(const double&);
		Complex& operator +=(const Complex&);
		
		Complex& operator -=(const double&);
		Complex& operator -=(const Complex&);	
		
		Complex& operator *=(const double&);
		Complex& operator *=(const Complex&);
		
		Complex& operator /=(const double&);
		Complex& operator /=(const Complex&);
		// Accessor and mutator methods
		double getRe();
		double getIm();
		void setRe(const double& );
		void setIm(const double& );
		double cabs(); // Method to compute the magnitude of the complex number
	private:
		
		double real; // Real part of the complex number
		double image; // Imaginary part of the complex number
		
};
